export { default } from "next-auth/middleware";
export const config = {
  matcher: [
    "/cart",
    "/changepassword",
    "/checkout",
    "/manageproducts",
    "/manageorders",
    "/product",
    "/profile",
  ],
  // makes the middleware run only on the specified routes
};
