"use client";
import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import Link from "next/link";
import styles from "@/styles/checkout.module.css";
import UploadButton from "@/components/UploadButton";
import ImageUploadPreview from "@/components/ImageUploadPreview";

import { signOut, useSession } from "next-auth/react";
import axios from "axios";
import { useRouter } from "next/navigation";

function Checkout() {
  const router = useRouter();

  const { data: session } = useSession();
  const [items, setItems] = useState([]);
  const [totalPrice, setTotalPrice] = useState(0);
  const [imageUrl, setImageUrl] = useState("");
  const [selectedPayment, setSelectedPayment] = useState("");
  const [tester, setTester] = useState("");
  const [shippingFee, setShippingFee] = useState(0);
  const [location, setLocation] = useState("");

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    reset,
    formState: { errors },
  } = useForm();

  useEffect(() => {
    setSelectedPayment(watch("paymentMethod"));
  }, [watch("paymentMethod")]);

  useEffect(() => {
    axios
      .get(`/api/register/${session.user.email}`)
      .then((res) => {
        const cartOwner = res.data.user.uEmail;

        axios
          .get(`/api/cart/${cartOwner}`)
          .then((cartRes) => {
            let cartData = cartRes.data.carts.item;

            // Ensure cartData is always an array
            if (!Array.isArray(cartData)) {
              cartData = cartData ? [cartData] : []; // Check if cartData is truthy before converting
            }

            const prdIDs = cartData.map((test) => test.prdID);

            // Fetch product details for each product in the cart
            Promise.all(
              prdIDs.map((prdID) => axios.get(`/api/product/${prdID}`))
            )
              .then((productResponses) => {
                // Update items state with product details
                const updatedCartItems = productResponses.map(
                  (prodRes, index) => {
                    const product = prodRes.data.products;
                    const cartItem = cartData[index];
                    return {
                      ...cartItem,
                      prdName: product.prdName,
                      prdPrice: product.prdPrice,
                      prdImage: product.prdImage,
                    };
                  }
                );
                setItems(updatedCartItems);
              })
              .catch((error) => {
                console.error("Error fetching product details:", error);
              });
          })
          .catch((error) => {
            console.error("Error fetching cart:", error);
          });
      })
      .catch((error) => {
        console.error("Error fetching user details:", error);
      });
  }, []); // Dependency array should be empty for running once

  useEffect(() => {
    // Calculate total price when items change
    const totalPrice = items.reduce(
      (acc, item) => acc + item.prdPrice * item.prdQuantity,
      0
    );
    setTotalPrice(totalPrice);
  }, [items]);

  // Inside your Checkout component
  const [priceToPay, setPriceToPay] = useState(0);

  // useEffect to recalculate priceToPay whenever totalPrice or shippingFee changes
  useEffect(() => {
    const totalPriceToPay = totalPrice + shippingFee;
    setPriceToPay(totalPriceToPay);
  }, [totalPrice, shippingFee]);

  const itemsArray = Object.values(items);

  // State to store the selected payment method
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState("GCASH");

  // Function to handle radio button change
  const handleRadioChange = (event) => {
    setSelectedPaymentMethod(event.target.value);
  };
  // Function to handle location change
  const handleLocationChange = (event) => {
    const selectedLocation = event.target.value;
    setLocation(selectedLocation);

    // Update shipping fee based on selected location
    if (selectedLocation === "Metro Manila") {
      setShippingFee(100);
    } else if (selectedLocation === "Luzon") {
      setShippingFee(110);
    } else if (selectedLocation === "Visayas") {
      setShippingFee(115);
    } else if (selectedLocation === "Mindanao") {
      setShippingFee(120);
    }
  };

  function handleUploadSuccess(result) {
    setImageUrl(result.info.secure_url);
  }

  const onSubmit = (data) => {
    const datas = {
      ...data,
      address: `${location}, ${data.address}`,
      orderOwner: session.user.email,
      customerName: data.customerName,
      transReceipt: imageUrl,
      totalPrice: priceToPay,
      items: items.map((item) => ({
        prdID: item.prdID,
        prdName: item.prdName,
        prdPrice: item.prdPrice,
        quantity: item.prdQuantity,
        prdColor: item.prdColor,
        prdSize: item.prdSize,
        prdImage: item.prdImage,
      })),
    };
    console.log(datas);

    axios.get(`/api/register/${session.user.email}`).then((res) => {
      const orderOwner = res.data.user.uEmail;
      console.log(orderOwner);
      axios.post(`/api/order/`, datas).then((orderRes) => {
        console.log(orderRes.data);
        axios.delete(`/api/cart/${orderOwner}`).then((cartRes) => {
          console.log(cartRes.data);

          items.forEach((item) => {
            axios.get(`/api/product/${item.prdID}`).then((prodRes) => {
              const product = prodRes.data.products;
              const availability = product.prdAvailability.find(
                (avail) => avail.color === item.prdColor
              );
              if (availability && availability.sizes[item.prdSize]) {
                // Decrease the quantity of the product in the database
                availability.sizes[item.prdSize] -= item.prdQuantity;

                // Patch the product in the database
                axios.patch(`/api/product/${item.prdID}`, product);
              }
            });
          });
        });
      });
    });
    router.push("/myorders");
  };

  const isFormValid = () => {
    const formData = {
      customerName: watch("customerName"),
      contactNum: watch("contactNum"),
      address: watch("address"),
      paymentReferenceNum: watch("paymentReferenceNum"),
      imageUrl: imageUrl,
    };

    const contactNumPattern = /^(09|\+639)\d{9}$/;

    for (const key in formData) {
      if (
        !formData[key] ||
        (key === "contactNum" && !contactNumPattern.test(formData[key]))
      ) {
        return false;
      }
    }

    return true;
  };

  return (
    <>
      <div className={styles.bgImage}>
        <div className="d-flex justify-content-center text-center mt-4 text-light">
          <h1>CHECKOUT</h1>
        </div>

        <div className={`${styles.checkoutBox} container my-3 bg-light`}>
          <div className="row justify-content-center p-2 fw-bold">
            SHOPPING CART
          </div>
          <div className={styles.checkoutCart}>
            <div className="row justify-content-center p-2">
              {itemsArray.map((cartItem) => (
                <div
                  className={`${styles.cartItems} container-flex p-3 mb-1`}
                  key={cartItem.prdID}
                >
                  <div className="col">
                    <div className="d-flex justify-content-between">
                      <div className="d-flex justify-content-start">
                        <img
                          src={cartItem.prdImage}
                          alt=""
                          width="110"
                          height="110"
                          className="d-inline-block align-text-top p-1"
                        />
                        <div>
                          <p
                            className={`${styles.cartItemTitles} fw-bold fs-5 m-0 text-start`}
                          >
                            {cartItem.prdName}
                          </p>
                          {cartItem.prdSize && (
                            <p className="m-0 text-start">
                              Size: {cartItem.prdSize}
                            </p>
                          )}
                          {cartItem.prdColor && (
                            <p className="m-0 text-start">
                              Color: {cartItem.prdColor}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="d-flex justify-content-end">
                        <div>
                          <p
                            className={`${styles.cartItemTitles} fs-5 m-0 text-end`}
                          >
                            PHP {cartItem.prdPrice}
                          </p>
                          <p className="m-0 text-end">
                            Qty: {cartItem.prdQuantity}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="row justify-content-center p-2">
            <p className="fw-bold text-end mt-2">
              Cart Subtotal: PHP {totalPrice}
            </p>
            <p className="fw-bold text-end">Shipping Fee: PHP {shippingFee} </p>
            <hr />
            <p className="fw-bold text-end text-dark h5">
              Total Price to Pay: PHP {priceToPay}
            </p>
          </div>
        </div>

        <div className={`${styles.checkoutBox} container my-3 bg-light`}>
          <div className="row">
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="form-group fw-bold">
                <label for="checkoutNameInput">Name</label>
                <input
                  type="text"
                  className="form-control"
                  id="checkoutNameInput"
                  placeholder="Enter Name"
                  required
                  {...register("customerName")}
                />
              </div>
              <div className="form-group fw-bold">
                <label for="checkoutContactInput">Contact Number</label>
                <input
                  type="number"
                  className="form-control"
                  id="checkoutContactInput"
                  placeholder="Enter Contact Number (ex: 09123456789)"
                  required
                  maxLength="11" // Set max length to 11 digits
                  {...register("contactNum")}
                  onInput={(e) => {
                    if (e.target.value.length > 11) {
                      e.target.value = e.target.value.slice(0, 11);
                    }
                  }}
                />
              </div>

              <div className="row pt-2 px-2 fw-bold">Location</div>
              <div className="form-group">
                <select
                  className={`${styles.selectBox} form-select`}
                  aria-label="Island Select"
                  value={location}
                  onChange={handleLocationChange}
                  required
                >
                  <option value="" disabled defaultValue={""}>
                    Select Location
                  </option>
                  <option value="Metro Manila">Metro Manila</option>
                  <option value="Luzon">Luzon</option>
                  <option value="Visayas">Visayas</option>
                  <option value="Mindanao">Mindanao</option>
                </select>
              </div>

              <div className="form-group fw-bold">
                <label for="checkoutAddressInput">Address</label>
                <input
                  type="text"
                  className="form-control"
                  id="checkoutContactInput"
                  placeholder="Enter Address"
                  required
                  {...register("address")}
                />
              </div>
              <div className="row pt-2 px-2 fw-bold">
                Choose a Payment Method
              </div>
              <div className="form-group">
                <select
                  className={`${styles.selectBox} form-select`}
                  aria-label="payment Select"
                  {...register("paymentMethod")}
                >
                  <option value="Gcash">Gcash</option>
                  <option value="Paymaya">Paymaya</option>
                </select>
              </div>
              <center>
                <div className={`${styles.scanPic} row py-2`}>
                  <p className="fw-bold">Scan To Pay</p>
                  {selectedPayment === "Gcash" ? (
                    <img
                      src="images/checkout-gcash-placeholder.png"
                      alt="GCASH"
                      width="300"
                      height="350"
                      className="d-inline-block align-text-top"
                    />
                  ) : (
                    <img
                      src="images/checkout-paymaya-placeholder.png"
                      alt="PAYMAYA"
                      width="300"
                      height="350"
                      className="d-inline-block align-text-top"
                    />
                  )}
                </div>
              </center>
              <div className="form-group py-2 fw-bold">
                <label for="checkoutAddressInput">
                  Enter Payment Reference Number
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="checkoutContactInput"
                  placeholder="Enter Payment Reference Number"
                  required
                  {...register("paymentReferenceNum")}
                />
              </div>

              <center>
                <div className={styles.uploadPic}>
                  <div className="mb-3">
                    <UploadButton onUpload={handleUploadSuccess} />
                  </div>
                  <div className="mb-3 text-center border border-dark p-0">
                    {!imageUrl ? (
                      <img
                        src="images/placeholder.png"
                        width={300}
                        height={300}
                        alt="placeholder.png"
                      />
                    ) : (
                      <ImageUploadPreview
                        imageUrl={imageUrl}
                        width={300}
                        height={300}
                      />
                    )}
                  </div>
                </div>
              </center>

              <div className="text-center">
                <button type="button" className="btn btn-danger mb-2 me-2">
                  <Link href="/cart" className="nav-link">
                    Cancel
                  </Link>
                </button>
                <button
                  type="submit"
                  className="btn btn-dark mb-2 me-2"
                  disabled={!isFormValid()}
                >
                  Checkout
                </button>
              </div>
            </form>
          </div>
        </div>

        <br />
        <br />
        <br />
      </div>
    </>
  );
}

export default Checkout;
