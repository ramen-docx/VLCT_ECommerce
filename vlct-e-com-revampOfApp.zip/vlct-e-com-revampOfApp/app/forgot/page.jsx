"use client";
// PasswordReset.js
import React, { useState, useEffect } from "react";
import Link from "next/link";
import axios from "axios";
import styles from "@/styles/forgot.module.css";

function PasswordReset() {
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [timer, setTimer] = useState(600);

  useEffect(() => {
    let interval;
    if (otpSent && timer > 0) {
      interval = setInterval(() => {
        setTimer((prevTimer) => prevTimer - 1);
      }, 1000);
    }
    if (timer === 0) {
      setOtp(""); // Reset the entered OTP
    }
    return () => clearInterval(interval);
  }, [otpSent, timer]);

  const checkUserExists = async () => {
    try {
      const response = await axios.get(`/api/send-email/${email}`);
      return response.data.exists;
    } catch (error) {
      console.error("Error checking user existence:", error);
      return false;
    }
  };

  const sendEmail = async () => {
    const userExists = await checkUserExists();
    if (!userExists) {
      alert("User doesn't exist. Please create an account first.");
      return;
    }
    axios
      .post(`/api/send-email/${email}`)
      .then(() => {
        alert("Email sent successfully. Please check your email for OTP.");
        setOtpSent(true);
        window.location.href = `/forgototp?email=${email}`; // Redirect to /forgototp
      })
      .catch(() => alert("Error sending email"));
  };

  const resendOTP = () => {
    setOtp("");
    setOtpSent(false);
    setTimer(600);
  };

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handleOtpChange = (e) => {
    setOtp(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios
      .post(`/api/verify-otp/${email}`, { enteredOtp: otp })
      .then(() => alert("OTP verified successfully"));
  };

  return (
    <div className={styles.bgImage}>
      <div className={`${styles.loginBox} container text-center my-5`}>
        <div className="login-container">
          <div className="login__group">
            <div className="d-flex justify-content-between mb-3"></div>
            <h2 className="mb-4">RETRIEVE PASSWORD</h2>
            <p>TO RESET YOUR PASSWORD, ENTER YOUR EMAIL</p>
            <br />
            <div className={`${styles.formGroup} form-group mb-3`}>
              <div
                className={`${styles.underlineTextfield} underline-textfield`}
              >
                <form onSubmit={handleSubmit}>
                  <input
                    type="email"
                    required
                    placeholder="Enter your email here"
                    value={email}
                    onChange={handleEmailChange}
                  />
                  <br />

                  <button className="btn btn-dark mt-3" onClick={sendEmail}>
                    Send Email
                  </button>
                </form>
              </div>

              {otpSent && (
                <p>
                  Time remaining: {Math.floor(timer / 60)}:{timer % 60}
                </p>
              )}

              <p>
                <Link href="/login" className="nav-link text-primary">
                  Back to Login Page
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default PasswordReset;
