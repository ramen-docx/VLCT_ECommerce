import styles from "@/styles/about.module.css";
import React from "react";
import Link from "next/link";

function AboutPage() {
  return (
    <>
      <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
      />
      <div className={styles.bgImage}>
        <div className="row">
          <div className=".col-6">
            <div className={`${styles.aboutus} container text-center`}>
              <div id="carouselExample" className="carousel slide">
                <div className="carousel-inner">
                  <div className="carousel-item active">
                    <img
                      src="images/carousel-1.png"
                      className="d-block w-100"
                      alt="..."
                      width="300px"
                      height="300px"
                    />
                  </div>
                  <div className="carousel-item">
                    <img
                      src="images/placeholder.png"
                      className="d-block w-100"
                      alt="..."
                      width="300px"
                      height="300px"
                    />
                  </div>
                  <div className="carousel-item">
                    <img
                      src="images/placeholder.png"
                      className="d-block w-100"
                      alt="..."
                      width="300px"
                      height="300px"
                    />
                  </div>
                </div>
                <button
                  className="carousel-control-prev"
                  type="button"
                  data-bs-target="#carouselExample"
                  data-bs-slide="prev"
                >
                  <span
                    className="carousel-control-prev-icon"
                    aria-hidden="true"
                  ></span>
                  <span className="visually-hidden">Previous</span>
                </button>
                <button
                  className="carousel-control-next"
                  type="button"
                  data-bs-target="#carouselExample"
                  data-bs-slide="next"
                >
                  <span
                    className="carousel-control-next-icon"
                    aria-hidden="true"
                  ></span>
                  <span className="visually-hidden">Next</span>
                </button>
              </div>

              <div className={`${styles.content1} container text-left`}>
                <h2 id="test" class="text-center">
                  VLCT Apparel Co.
                </h2>
                <br></br>
                <h5>History:</h5> <br></br>
                Velocity was founded by John Ver Zuniega, also known as "JV," on
                April 18, 2020. Inspired by his innate creativity and passion
                for multimedia arts, JV embarked on a journey to share his
                unique designs with the world.<br></br>
                <br></br>
                <h5>Mission Statement:</h5>
                <br></br>
                Velocity is dedicated to empowering individuals to express their
                unique style through original designs that blend creativity,
                innovation, and accessibility. We strive to provide
                fashion-forward individuals of all ages with affordable yet
                quality apparel, embodying a brand personality characterized by
                energy, positivity, and determination. Through bold visual
                identity, inclusive brand voice, and strategic partnerships, we
                aim to create a vibrant community where everyone can feel valued
                and understood. Our mission is to continuously expand our
                product line and reach, remaining a trusted destination for
                trend-setting fashion that doesn't break the bank<br></br>
                <br></br>
                <h5>Values:</h5>
                <br></br>
                Velocity is driven by the values of creativity, innovation, and
                accessibility. They believe in empowering individuals to express
                themselves through fashion without breaking the bank.<br></br>
                <br></br>
                <h5>Target Audience:</h5>
                <br></br>
                Velocity caters to individuals who appreciate original designs
                and seek affordable fashion options without compromising on
                quality. Their target demographic includes fashion-forward
                individuals of all ages.<br></br>
                <br></br>
                <h5>Unique Selling Proposition (USP):</h5>
                <br></br>
                What sets Velocity apart is its commitment to delivering stylish
                apparel at an affordable price point. By leveraging JV's
                creativity and strategic approach to production, Velocity offers
                customers unique designs that stand out from mainstream fashion
                trends.<br></br>
                <br></br>
                <h5>Brand Personality:</h5>
                <br></br>
                Velocity embodies traits of creativity, positivity, and
                determination. Their brand exudes a sense of energy and
                dynamism, mirroring the speed and direction implied by their
                name.<br></br>
                <br></br>
                <h5>Visual Identity:</h5>
                <br></br>
                Velocity's visual identity features bold typography and vibrant
                colors that reflect their energetic brand personality. Their
                logo conveys a sense of movement and momentum, reinforcing the
                brand's commitment to speed and quality.<br></br>
                <br></br>
                <h5>Brand Voice:</h5>
                <br></br>
                Velocity communicates with a tone that is approachable, upbeat,
                and customer-centric. Their messaging emphasizes inclusivity and
                affordability, making customers feel valued and understood.
                <br></br>
                <br></br>
                <h5>Brand Associations:</h5>
                <br></br>
                Velocity seeks partnerships and collaborations that align with
                their values of creativity and accessibility. They aim to build
                a community of like-minded individuals who share a passion for
                unique fashion.<br></br>
                <br></br>
                <h5>Future Goals:</h5>
                <br></br>
                Looking ahead, Velocity aims to expand its product line and
                reach a broader audience while maintaining its commitment to
                affordability and quality. They aspire to become a go-to
                destination for fashion-forward individuals seeking trendy yet
                affordable clothing options.<br></br>
                <br></br>
                <h5>Achievements of Velocity:</h5>
                <br></br>
                1. Vertical Integration: Velocity has transitioned from solely
                creating designs and selling through third-party platforms to
                establishing its own shirt brand. They now handle their own
                printing and packaging, allowing for greater control over the
                production process and brand identity.<br></br>
                2. Diversification: In addition to their clothing line, Velocity
                has expanded into the perfume business with Velocity Scents.
                Furthermore, they have ventured into jersey printing with
                Velocity Jersey Printing, offering personalized items beyond
                apparel.<br></br>
                3. Academic Recognition: Velocity's innovative approach has
                garnered attention from academic institutions. They were chosen
                by IT students from the University of Santo Tomas (UST) for a
                collaboration to develop the Velocity website as a final
                project, demonstrating recognition of their brand's relevance
                and appeal in digital spaces.<br></br>
                4. Featured Speaker: Velocity was invited and featured at
                Trinity University of Asia's Senior Eye third live session. The
                session, themed "SHSark Tank: Learn how to be financially
                resilient during this pandemic," recognized Velocity's
                entrepreneurial journey as a model for financial resilience and
                innovation, showcasing their success to a wider audience.
                <br></br>
                <br></br>
                These achievements underscore Velocity's evolution from a
                budding fashion brand to a multifaceted business with a strong
                presence in both the digital and physical realms. Their
                commitment to quality, innovation, and community engagement has
                positioned them as a leader in the fashion industry.
                <p></p>
              </div>

              <div className="row">
                <div className="col-6">
                  <div className={`${styles.content2} container text-center`}>
                    <h2 id="test">Socials</h2>
                    <p>
                      Stay updated and engaged by connecting with us on social
                      media.
                    </p>
                    <div className="row pe-3">
                      <div className="col-4">
                        <Link
                          href="https://www.facebook.com/VelocityPh/photos"
                          className={`${styles.facebook} fa fa-facebook `}
                        ></Link>
                      </div>

                      <div className="col-4">
                        <Link
                          href="https://www.instagram.com/velocity_ph/"
                          className={`${styles.instagram} fa fa-instagram `}
                        ></Link>
                      </div>
                      <div className="col-4">
                        <Link
                          href="https://www.tiktok.com/@velocity_ph"
                          className={`${styles.tiktok}`}
                        >
                          <img
                            src="images/Tiktok.png"
                            alt="..."
                            width="30px"
                            height="30px"
                          />
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-6">
                  <div className={`${styles.content2} container text-center`}>
                    <h2 id="test">Contact Us!</h2>
                    <p>
                      Have questions or want to get in touch? Feel free to send
                      us an email at{" "}
                      <a
                        className="text-body"
                        href="mailto:vlctapparelco@gmail.com"
                      >
                        vlctapparelco@gmail.com
                      </a>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default AboutPage;
