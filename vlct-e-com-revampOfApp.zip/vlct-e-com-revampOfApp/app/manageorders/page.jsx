"use client";
import React from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import axios from "axios";
import ManageOrder from "@/components/ManageOrder";

export default function manageorders() {
  const { data: session, status } = useSession();
  const router = useRouter();

  if (status === "loading") return <p>Loading...</p>;
  axios.get(`/api/register/${session.user.email}`).then((res) => {
    if (res.data.user.uRole !== "admin") {
      router.push("/");
    }
  });
  return <ManageOrder />;
}
