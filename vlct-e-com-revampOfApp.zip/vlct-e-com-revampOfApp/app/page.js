// pages/index.js
"use client";
import AaHomepage from "@/components/AaHomepage.jsx";
import styles from "@/app/page.module.css";

import React, { useRef } from "react";

export default function Home() {
  const cardContainerRef = useRef(null);

  const scrollToCardContainer = () => {
    cardContainerRef.current.scrollIntoView({ behavior: "smooth" });
  };
  return (
    <>
      <div className={styles.parallax}>
        <div className={styles.overlay}></div>
        <div className={styles.titleGroup}>
          <h1 className={styles.titleWelcome}>WELCOME TO VLCT APPAREL CO.</h1>
          <button className={styles.shopButton} onClick={scrollToCardContainer}>
            Shop Now
          </button>
        </div>
      </div>
      <AaHomepage cardContainerRef={cardContainerRef} />
    </>
  );
}
