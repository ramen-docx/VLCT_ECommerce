"use client";
import React from "react";
import DataPrivacyModal from "@/components/DataPrivacyModal";

function DataPriv() {
  return (
    <>
      <div>
        <DataPrivacyModal />
      </div>
    </>
  );
}

export default DataPriv;
