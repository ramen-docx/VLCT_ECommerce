import styles from "@/styles/myorders.module.css";
import CheckoutCartItems from "@/components/CheckoutCartItems";

function ViewOrder() {
  return (
    <>
      <div className={styles.bgImage}>
        <div className={`${styles.myOrdersBox} container text-center my-5`}>
          <div className={`${styles.borderInside} h-100`}>
            <div className={`${styles.insideBorder} h-100 w-100 px-4`}>
              <h2 className="text-center pt-3 fw-bold">My Orders</h2>
              <div className="container pt-2">
                <div className="d-flex bd-highlight mb-3">
                  <div className="h2 me-auto ps-5 bd-highlight">
                    <span className={styles.myOrdersTitle}>
                      Order: <p className="text-center h4 mb-0 pe-2">1</p>
                    </span>
                  </div>
                  <div className="pt-2 pe-2 bd-highlight text-secondary">
                    Date Ordered: mm/dd/yy
                  </div>
                  <div className="pt-2 pe-5 bd-highlight text-secondary">
                    Transaction Order ID: 123456789
                  </div>
                </div>
              </div>
              <hr className={`${styles.lineBreak} mx-5`}></hr>
              <div className={styles.myOrdersContent}>
                <CheckoutCartItems />
                <CheckoutCartItems />
                <CheckoutCartItems />
                <CheckoutCartItems />
                <CheckoutCartItems />
              </div>
              <hr className={`${styles.lineBreak} mx-5 mt-2`}></hr>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default ViewOrder;
