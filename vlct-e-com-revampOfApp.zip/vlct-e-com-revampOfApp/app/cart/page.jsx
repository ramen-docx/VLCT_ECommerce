"use client";
import styles from "@/styles/cart.module.css";
import React from "react";

import Link from "next/link";
import { useState, useEffect } from "react";
import axios from "axios";
import { useForm } from "react-hook-form";
import { signOut, useSession } from "next-auth/react";

function CartPage() {
  const { data: session } = useSession();
  const [items, setItems] = useState([]);
  const [totalPrice, setTotalPrice] = useState(0);
  const [error, setError] = useState();

  const {
    //lagay ko lang para if gagamitin hahaha
    register,
    handleSubmit,
    watch,
    reset,
    setValue,
    formState: { errors },
  } = useForm();

  //on load fetch all the items in the cart of the user logged in
  // store it in the items
  useEffect(() => {
    axios
      .get(`/api/cart/${session.user.email}`)
      .then((cartRes) => {
        const cartData = cartRes.data.carts;
        let cartDataArray = Array.isArray(cartData.item)
          ? cartData.item
          : [cartData.item];
        // Use Promise.all to wait for all API calls to complete
        console.log("cartDataArray: ", cartDataArray);
        Promise.all(
          cartDataArray.map((item) =>
            axios.get(`/api/product/${item.prdID}`).then((prodRes) => {
              console.log("prodRes: ", prodRes.data.products);
              console.log("item: ", item);
              return {
                ...item,
                prdName: prodRes.data.products.prdName,
                prdPrice: prodRes.data.products.prdPrice,
                prdImage: prodRes.data.products.prdImage,
              };
            })
          )
        )
          .then((updatedCartItems) => {
            setItems(updatedCartItems);
          })
          .catch((error) => {
            console.error("Error fetching product details:", error);
          });
      })
      .catch((error) => {
        console.error("Error fetching cart:", error);
      });
  }, []);

  // when items is saved
  useEffect(() => {
    // Calculate total price when items change
    const totalPrice = items.reduce((total, item) => {
      return total + item.prdPrice * item.prdQuantity;
    }, 0);
    setTotalPrice(totalPrice);
  }, [items]);

  const itemsArray = Object.values(items);

  const quantityAddHandler = async (cartItem) => {
    // Fetch product details from the database
    const prodRes = await axios.get(`/api/product/${cartItem.prdID}`);
    const product = prodRes.data.products;

    // Find the availability for the item's color and size
    const availability = product.prdAvailability.find(
      (availability) => availability.color === cartItem.prdColor
    );
    console.log("availability: ", availability);
    console.log("cartItem: ", cartItem);
    // Check if the color and size are available
    if (availability && availability.sizes[cartItem.prdSize]) {
      // Get the stock for the color and size
      const stock = availability.sizes[cartItem.prdSize];

      // Check if the stock is enough
      if (stock > cartItem.prdQuantity) {
        // If the stock is enough, increase the quantity
        const updatedItems = items.map((item) => {
          if (
            item.prdID === cartItem.prdID &&
            item.prdColor === cartItem.prdColor &&
            item.prdSize === cartItem.prdSize
          ) {
            return {
              ...item,
              prdQuantity: item.prdQuantity + 1,
            };
          }
          return item;
        });

        setItems(updatedItems);
        axios
          .patch(`/api/cart/${session.user.email}`, { item: updatedItems })
          .then((res) => {
            console.log("Cart updated:", res.data);
          })
          .catch((error) => {
            console.error("Error updating cart:", error);
          });
      } else {
        // If the stock is not enough, show an error message
        console.error("Not enough stock for this product, color, and size");
      }
    } else {
      // If the color and size are not available, show an error message
      console.error("This color and size are not available");
      setError("Available Stocks have been exceeded.");
    }
  };

  const quantityDecrementHandler = (cartItem) => {
    const updatedItems = items.map((item) => {
      if (
        item.prdID === cartItem.prdID &&
        item.prdSize === cartItem.prdSize &&
        item.prdQuantity > 0
      ) {
        return {
          ...item,
          prdQuantity: item.prdQuantity - 1,
        };
      }
      return item;
    });

    setItems(updatedItems);
    console.log("updatedItems: ", updatedItems);
    axios
      .patch(`/api/cart/${session.user.email}`, { item: updatedItems })
      .then((res) => {
        console.log("Cart updated:", res.data.updatedCart);
      })
      .catch((error) => {
        console.error("Error updating cart:", error);
      });
  };

  const deleteItem = (prdID, prdColor, prdSize) => {
    // Create a new array that does not include the item to be deleted
    console.log("items: ", items);
    const updatedItems = items.filter(
      (item) =>
        item.prdID !== prdID ||
        item.prdColor !== prdColor ||
        item.prdSize !== prdSize
    );
    console.log("updatedItems: ", updatedItems);

    // Update the items state
    setItems(updatedItems);

    // Update the cart in the database
    axios
      .patch(`/api/cart/${session.user.email}`, { item: updatedItems })
      .then((res) => {
        console.log("Cart updated:", res.data);
      })
      .catch((error) => {
        console.error("Error updating cart:", error);
      });
  };

  const onSubmit = (data) => {
    axios.get(`/api/register/${session.user.email}`).then((res) => {
      const cartOwner = res.data.user._id;
      axios.get(`/api/cart/${cartOwner}`).then((cartRes) => {
        console.log("cart submitted", cartRes.data);
      });
      axios.patch(`/api/cart/${cartOwner}`).then((patchRes) => {
        console.log(patchRes);
      });
    });
  };

  return (
    <>
      <div className={styles.bgImage}>
        <div className={`${styles.cartBox} container text-center my-5`}>
          <div className="d-flex justify-content-between mx-3 p-3">
            <div className="d-flex justify-content-start mx-3">
              <h2 className={styles.cartBoxTitles}>CART</h2>
              <img
                src="images/shopping-cart.png"
                alt=""
                width="40"
                height="40"
                className="d-inline-block align-text-top ms-1"
              />
            </div>
            <div className="d-flex justify-content-end">
              <h3 className="mr-1">
                <div className={styles.cartBoxTitles}>
                  Total Price: PHP {totalPrice}
                </div>
              </h3>
            </div>
          </div>
          <div className={styles.cartContents}>
            {error && <p className="text-danger">{error}</p>}
            <form onSubmit={handleSubmit(onSubmit)}>
              {itemsArray.length === 0 ? (
                <p className="fs-5">No products added yet</p>
              ) : (
                itemsArray.map((cartItem, index) => (
                  <div
                    className={`${styles.cartItems} container-flex p-3 mb-1`}
                    key={index}
                  >
                    <div className="col">
                      <div className="d-flex justify-content-between">
                        <div className="d-flex justify-content-start">
                          <img
                            src={cartItem.prdImage}
                            alt=""
                            width="110"
                            height="110"
                            className="d-inline-block align-text-top p-1"
                          />
                          <div>
                            <p
                              className={`${styles.cartItemTitles} fw-bold fs-5 m-0 text-start`}
                            >
                              {cartItem.prdName}
                            </p>
                            {cartItem.prdSize && (
                              <p className="m-0 text-start">
                                Size: {cartItem.prdSize}
                              </p>
                            )}
                            {cartItem.prdColor && (
                              <p className="m-0 text-start">
                                Color: {cartItem.prdColor}
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="d-flex justify-content-end">
                          <div>
                            <p
                              className={`${styles.cartItemTitles} fs-5 m-0 text-end`}
                            >
                              PHP {cartItem.prdPrice}
                            </p>
                            <div
                              className={`${styles.cartQuantity} text-center`}
                            >
                              <div className="input-group mb-3 mx-0">
                                <div className="input-group-prepend">
                                  <button
                                    className="btn btn-outline-dark bg-light rounded-0"
                                    type="button"
                                    onClick={() =>
                                      quantityDecrementHandler(cartItem)
                                    }
                                  >
                                    -
                                  </button>
                                </div>
                                <input
                                  type="text"
                                  className="form-control bg-light text-dark border-black rounded-0 fw-bold text-center p-0"
                                  id="quantity"
                                  value={cartItem.prdQuantity}
                                  disabled
                                  {...register("quantityBought")}
                                />
                                <div className="input-group-append">
                                  <button
                                    className="btn btn-outline-dark bg-light rounded-0"
                                    type="button"
                                    onClick={() => quantityAddHandler(cartItem)}
                                  >
                                    +
                                  </button>
                                </div>
                              </div>
                              <div className="text-end">
                                <button
                                  type="button"
                                  className="bg-secondary text-light"
                                  onClick={() => {
                                    deleteItem(
                                      cartItem.prdID,
                                      cartItem.prdColor,
                                      cartItem.prdSize
                                    );
                                  }}
                                >
                                  Remove
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </form>
          </div>
          <div className="d-grid gap-2 d-md-flex justify-content-md-end mt-3 p-1">
            <button className="btn btn-secondary mx-0" type="button">
              <Link href="/" className="nav-link">
                Continue Shopping
              </Link>
            </button>
            <button
              className="btn btn-secondary me-0"
              type="button"
              disabled={itemsArray.length === 0}
            >
              <Link href="/checkout" className="nav-link">
                Checkout
              </Link>
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

export default CartPage;
