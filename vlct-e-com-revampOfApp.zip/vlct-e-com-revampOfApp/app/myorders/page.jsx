"use client";
// react imports
import React from "react";
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useRouter } from "next/navigation";
import { signOut, useSession } from "next-auth/react";
import axios from "axios";
import Link from "next/link";

import styles from "@/styles/myorders.module.css";

import ViewOrderModal from "@/components/ViewOrderModal";

function MyOrders() {
  const { data: session } = useSession();
  const [myOrders, setMyOrders] = useState([]);

  const [yeetedID, setYeetedID] = useState();
  const [yeetedOrder, setYeetedOrder] = useState([]);

  useEffect(() => {
    if (session?.user?.email) {
      axios.get(`/api/register/${session.user.email}`).then((res) => {
        const email = res.data.user.uEmail;

        axios.get(`/api/order/${email}`).then((ordersRes) => {
          setMyOrders(ordersRes.data.orders);
        });
      });
    }
  }, []);
  const myOrdersArray = myOrders ? Object.values(myOrders) : [];

  function useSetYeetedShiz(ID, myOrdersList) {
    setYeetedID(ID);
    setYeetedOrder(myOrdersList);
  }

  return (
    <>
      <div className={styles.bgImage}>
        <div className={`${styles.myOrdersBox} container text-center my-5`}>
          <h2 className="text-center pt-3 fw-bold">My Orders</h2>
          <div className={`${styles.tableContainer} ${styles.tableOverflow}`}>
            <table className={`${styles.tableFont} table table-bordered`}>
              <thead>
                <tr>
                  <th scope="col">Date Ordered</th>
                  <th scope="col">Order Status</th>
                  <th scope="col">Payment Method</th>
                  <th scope="col">Payment Reference #</th>
                  <th scope="col">View Order</th>
                </tr>
              </thead>
              <tbody>
                {myOrdersArray.length === 0 ? (
                  <tr>
                    <td colSpan="5">No products yet</td>
                  </tr>
                ) : (
                  myOrdersArray.map((myOrdersList) => (
                    <tr key={myOrdersList._id}>
                      <th scope="row">{myOrdersList.orderDate}</th>
                      <td>{myOrdersList.orderStatus}</td>
                      <td>{myOrdersList.paymentMethod}</td>
                      <td>{myOrdersList.paymentReferenceNum}</td>
                      <td>
                        <button
                          type="button"
                          className={`${styles.btnView} btn btn-dark`}
                          data-bs-toggle="modal"
                          data-bs-target="#viewOrderModal"
                          onClick={() => {
                            useSetYeetedShiz(myOrdersList._id, myOrdersList);
                          }}
                        >
                          View
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
            {myOrdersArray.length === 0 && (
              <Link href="/">
                <button className="btn btn-dark fw-bold">Shop Now</button>
              </Link>
            )}
            <ViewOrderModal
              setOrders={setMyOrders}
              setYeetedID={yeetedID}
              orderList={yeetedOrder}
            />
          </div>
        </div>
      </div>
    </>
  );
}

export default MyOrders;
