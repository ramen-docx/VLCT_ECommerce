"use client";
import { useEffect } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import LoginForm from "@/components/LoginForm";

export default function Login() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const loading = status === "loading";

  useEffect(() => {
    if (session) {
      router.push("/"); // Redirect to homepage if session exists
    }
  }, [session]);

  if (loading) {
    return null;
  } else {
    return <LoginForm />;
  }
}
