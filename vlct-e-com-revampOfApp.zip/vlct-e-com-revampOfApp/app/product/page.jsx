"use client";
import styles from "@/styles/product.module.css";
import React from "react";
import Link from "next/link";

import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useRouter } from "next/navigation";
import { signOut, useSession } from "next-auth/react";
import axios from "axios";
import { set } from "mongoose";

function Product() {
  const [formData, setFormData] = useState({
    productName: "",
    size: "",
    colorfamily: "",
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    // Validate form data before submitting (e.g., using a validation library)
    console.log("Form data:", formData);
    // Submit form data using an API call or other logic
  };
  return (
    <>
      <div className="modal-dialog">
        <div className="modal-content h6">
          <div className="modal-header">
            <h1 className="modal-title fs-5 fw-bold" id="addModalLabel">
              Add Product
            </h1>
            <button
              type="button"
              className="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
              onClick={handleDismiss}
            ></button>
          </div>
          <div className="modal-body text-start">
            <div className={styles.bgImage}>
              <div className={styles.productcontainer}>
                <form className={styles.formCorner} onSubmit={handleSubmit}>
                  <div
                    className={`${styles.productimage} d-flex justify-content-center`}
                  >
                    <img
                      src="images/placeholder.png"
                      alt=""
                      width="500"
                      height="500"
                      className={styles.image}
                    />
                  </div>

                  <div className={`${styles.formRow} justify-content-center`}>
                    <div className={styles.formGroup}>
                      <label id="productname">Name of Product</label>
                    </div>
                  </div>

                  <div className={styles.formRow}>
                    <div className={styles.formGroup}>
                      <label htmlFor="size">Size</label>
                      <select
                        id="size"
                        className={`${styles.formControl}`}
                        name="size"
                        value={formData.size}
                        onChange={handleChange}
                      >
                        <option value="">Choose size...</option>
                        {/* ... your size options ... */}
                      </select>
                    </div>

                    <div className={styles.formGroup}>
                      <label htmlFor="colorfamily">Color Family</label>
                      <select
                        id="colorfamily"
                        className={`${styles.formControl}`}
                        name="colorfamily"
                        value={formData.colorfamily}
                        onChange={handleChange}
                      >
                        <option value="">Choose color...</option>
                        {/* ... your colorfamily options ... */}
                      </select>
                    </div>
                  </div>

                  <div
                    className={`${styles.productdescription} d-flex justify-content-center`}
                  >
                    <label>
                      <textarea
                        className={`${styles.bgLight} ${styles.textDark}`}
                        name="postContent"
                        defaultValue="Product Description"
                        disabled
                        rows={8}
                        cols={80}
                      />
                    </label>
                  </div>

                  <div
                    className={`${styles.col12} d-flex justify-content-center`}
                  >
                    <img
                      src="images/Fb.png"
                      alt="FB Icon"
                      width="20"
                      height="20"
                      className="d-inline-block align-text-top ms-1"
                    />
                    <a href="#" className={`${styles.badge} badge-primary`}>
                      Facebook
                    </a>
                    <br />
                    <a href="#" className={`${styles.badge} badge-secondary`}>
                      <img
                        src="images/Tiktok.png"
                        alt="FB Icon"
                        width="30"
                        height="30"
                        className="d-inline-block align-text-top ms-1"
                      />
                      Tiktok
                    </a>
                    <br />
                    <a href="#" className={`${styles.badge} badge-success`}>
                      <img
                        src="images/Ig.png"
                        alt="FB Icon"
                        width="25"
                        height="25"
                        className="d-inline-block align-text-top ms-1"
                      />
                      Instagram
                    </a>
                  </div>

                  <br />

                  <div className={`${styles.flexBdHighlight} mb-3 d-flex`}>
                    <div className={`me-auto p-2 ${styles.bdHighlight}`}>
                      <button
                        className={`${styles.btnSecondary} mx-0 btn btn-secondary`}
                        type="button"
                      >
                        Statistics
                      </button>
                    </div>
                    <div className={`p-2 ${styles.bdHighlight}`}>
                      <Link href="/">
                        <button
                          className={`${styles.btnSecondary} mx-0 btn btn-secondary`}
                          type="button"
                        >
                          Home
                        </button>
                      </Link>
                    </div>
                    <div className={`p-2 ${styles.bdHighlight}`}>
                      <button
                        type="submit"
                        className={`${styles.btnPrimary} btn btn-primary`}
                      >
                        Add to Cart
                        <img src="public/images/shopping-cart.png" alt="" />
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
export default Product;
