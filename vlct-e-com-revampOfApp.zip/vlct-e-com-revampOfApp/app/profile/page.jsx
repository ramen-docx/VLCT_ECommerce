"use client";
import ProfileForms from "@/components/ProfileForms";

// react imports
import React from "react";
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import axios from "axios";
import Link from "next/link";

export default function profile() {
  return (
    <>
      <ProfileForms />
    </>
  );
}
