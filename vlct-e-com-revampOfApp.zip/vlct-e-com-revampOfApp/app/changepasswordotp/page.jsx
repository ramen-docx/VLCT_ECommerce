"use client";
import styles from "@/styles/register.module.css";

// react imports
import React from "react";
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useRouter } from "next/navigation";
import { signOut, useSession } from "next-auth/react";
import axios from "axios";
import Link from "next/link";
import { useSearchParams } from "next/navigation";

function ChangePassword() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const email = searchParams.get("email");

  const {
    register,
    handleSubmit,
    watch,
    reset,
    formState: { errors },
  } = useForm();

  const handleChangePassword = (data) => {
    const password = watch("uPassword");
    const confirmPassword = watch("ConfirmPassword");

    if (password !== confirmPassword) {
      alert("Passwords do not match");
      return;
    } else {
      onSubmit(data);
      return;
    }
  };

  const onSubmit = (data) => {
    const changeEmailData = { ...data, email };
    console.log(changeEmailData);
    axios.patch("/api/changePassword", changeEmailData).then((res) => {
      reset();
      router.push("/login");
    });
  };

  return (
    <div className={styles.bgImage}>
      <div className={`${styles.loginBox} container text-center my-5`}>
        <div className="register-container mx-md-5">
          <div className="register_group">
            <br />
            <h2 className="mb-3">Change Password</h2>
            <form onSubmit={handleSubmit(handleChangePassword)}>
              <div className="form-floating mb-3 mx-3">
                <input
                  type="password"
                  id="newPassword"
                  name="newPassword"
                  required
                  placeholder="New Password"
                  className="form-control"
                  {...register("uPassword")}
                />
                <label htmlFor="newPassword">New Password</label>
              </div>

              <div className="form-floating mb-3 mx-3">
                <input
                  type="password"
                  id="confirmNewPassword"
                  name="confirmNewPassword"
                  required
                  placeholder="Confirm New Password"
                  className="form-control"
                  {...register("ConfirmPassword")}
                />
                <label htmlFor="confirmNewPassword">Confirm New Password</label>
              </div>

              <br />

              <button
                className={`${styles.loginbutton} btn btn-light login-button mb-2`}
              >
                Change Password
              </button>
            </form>
            {/* ======================= end of form ======================= */}

            <Link href="/profile" className="nav-link text-primary">
              <button
                type="button"
                className={`${styles.cancelbutton} btn btn-light login-button mb-2`}
              >
                Cancel
              </button>
            </Link>
            <br />
            {/* pakiayos na yung container d fixed yung size */}
          </div>
        </div>
      </div>
    </div>
  );
}

export default ChangePassword;
