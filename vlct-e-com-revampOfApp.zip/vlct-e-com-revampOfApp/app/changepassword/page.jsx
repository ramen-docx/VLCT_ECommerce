"use client";
import styles from "@/styles/register.module.css";

// react imports
import React from "react";
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useRouter } from "next/navigation";
import { signOut, useSession } from "next-auth/react";
import axios from "axios";
import Link from "next/link";
import { set } from "mongoose";

function ChangePassword() {
  const router = useRouter();
  const [error, setError] = useState("");
  const { data: session, status } = useSession();
  const [email, setLoggedEmail] = useState(session?.user?.email);
  const [userDetails, setUserDetails] = useState({});
  const [hasPassword, setHasPassword] = useState();
  const {
    register,
    handleSubmit,
    watch,
    reset,
    formState: { errors },
  } = useForm();

  useEffect(() => {
    axios
      .get(`/api/changePass/${email}`)
      .then((res) => {
        console.log(res.data);
        setHasPassword(res.data.hasPassword);
      })
      .catch((err) => {
        console.log(err.response.data);
        console.error("Error during fetching of user's password:", err);
      });
  }, []);

  const onSubmit = async (data, e) => {
    e.preventDefault();
    const passwords = {
      oldPassword: watch("oldPassword"),
      newPassword: watch("newPassword"),
      confirmPassword: watch("confirmNewPassword"),
    };

    axios
      .patch(`/api/changePass/${email}`, passwords)
      .then((res) => {
        setUserDetails(res.data.user);
        router.push("/profile");
      })
      .catch((err) => {
        if (err.response) {
          setError(err.response.data.message);
        } else {
          console.error("Error during changing of password:", err);
        }
      });
  };
  return (
    <div className={styles.bgImage}>
      <div className={`${styles.loginBox} container text-center my-5`}>
        <div className="register-container mx-md-5">
          <div className="register_group">
            <br />
            <h2 className="mb-3">Change Password</h2>
            {error && (
              <div className="alert alert-danger text-center">{error}</div>
            )}
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="form-floating mb-3 mx-3">
                {hasPassword && (
                  <>
                    <input
                      type="password"
                      id="oldPassword"
                      name="oldPassword"
                      required
                      placeholder="Old Password"
                      className="form-control"
                      {...register("oldPassword")}
                    />
                    <label htmlFor="oldPassword">Old Password</label>
                  </>
                )}
              </div>
              <div className="form-floating mb-3 mx-3">
                <input
                  type="password"
                  id="newPassword"
                  name="newPassword"
                  required
                  placeholder="New Password"
                  className="form-control"
                  {...register("newPassword")}
                />
                <label htmlFor="newPassword">New Password</label>
              </div>

              <div className="form-floating mb-3 mx-3">
                <input
                  type="password"
                  id="confirmNewPassword"
                  name="confirmNewPassword"
                  required
                  placeholder="Confirm New Password"
                  className="form-control"
                  {...register("confirmNewPassword")}
                />
                <label htmlFor="confirmNewPassword">Confirm New Password</label>
              </div>

              <br />

              <button
                className={`${styles.loginbutton} btn btn-light login-button mb-2`}
              >
                Change Password
              </button>
            </form>
            {/* ======================= end of form ======================= */}

            <Link href="/profile" className="nav-link text-primary">
              <button
                type="button"
                className={`${styles.cancelbutton} btn btn-light login-button mb-2`}
              >
                Cancel
              </button>
            </Link>
            <br />
            {/* pakiayos na yung container d fixed yung size */}
          </div>
        </div>
      </div>
    </div>
  );
}

export default ChangePassword;
