import connectToDatabase from "@/utils/database";
import Users from "@/models/users";
import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";

export async function POST(NextRequest) {
  try {
    await connectToDatabase();

    const { uName, uEmail, uPassword, uFName, uLName } =
      await NextRequest.json();

    // ======================================= Start off checkers =======================================

    // ============= checker if email or username already exists =============
    const existingUsername = await Users.findOne({ uName: uName });
    if (existingUsername) {
      return NextResponse.json(
        { message: "Username already taken" },
        { status: 400 }
      );
    }
    const existingEmail = await Users.findOne({ uEmail: uEmail });
    if (existingEmail) {
      return NextResponse.json(
        { message: "Email already taken" },
        { status: 400 }
      );
    }

    // ============= Check if password meets requirements =============
    const passwordRegex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*(),.?":{}|<>])[A-Za-z\d!@#$%^&*(),.?":{}|<>]{8,}$/;

    if (!passwordRegex.test(uPassword)) {
      return NextResponse.json(
        {
          message:
            "Password should have at least one uppercase and lowercase letter, one digit, and one special character. Minimum of 8 characters",
        },
        { status: 400 }
      );
    }
    const hashedPassword = await bcrypt.hash(uPassword, 10);

    // ======================================= end of checkers =======================================

    const newUsers = await Users.create({
      uName,
      uEmail,
      uPassword: hashedPassword,
      uFName,
      uLName,
    });
    return NextResponse.json({ newUsers }, { status: 201 });
  } catch (error) {
    return NextResponse.json(
      { message: "Error while registering" },
      { status: 500 }
    );
  }
}
