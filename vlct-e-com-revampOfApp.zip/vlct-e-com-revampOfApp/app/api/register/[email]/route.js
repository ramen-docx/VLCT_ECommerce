import connectToDatabase from "@/utils/database";
import Users from "@/models/users";
import { NextRequest, NextResponse } from "next/server";

export const GET = async (NextRequest, { params }) => {
  const email = params.email;

  // palagi yung params.<?> is yung name nung folder na gagawing param
  try {
    await connectToDatabase();

    const user = await Users.findOne({ uEmail: email }).select("-uPassword");
    // select("-<table header shiz>") is to exclude shizz from the response

    if (!user) {
      return NextResponse.json({ message: "User not found" }, { status: 404 });
    }

    return NextResponse.json({ user }, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      { message: "Error while fetching users" },
      { status: 501 }
    );
  }
};

export const PATCH = async (NextRequest, { params }) => {
  const email = params.email;
  const currentAccountDetails = await Users.findOne({ uEmail: email });

  try {
    await connectToDatabase();
    const {
      uEmail,
      uName,
      uFName,
      uLName,
      uGender,
      uPronouns,
      uBirthdate,
      uImg,
    } = await NextRequest.json();

    function isUserDataUnchanged(userInput, currentData) {
      return (
        userInput.uName === currentData.uName &&
        userInput.uEmail === currentData.uEmail &&
        userInput.uFName === currentData.uFName &&
        userInput.uLName === currentData.uLName &&
        userInput.uEmail === currentData.uEmail &&
        userInput.uGender === currentData.uGender &&
        userInput.uPronouns === currentData.uPronouns &&
        userInput.uBirthdate === currentData.uBirthdate &&
        userInput.uImg === currentData.uImg
      );
    }

    // CHECKERS ========================================================================================================
    const userInputSameNoChange = isUserDataUnchanged(
      {
        uName,
        uEmail,
        uFName,
        uLName,
        uEmail,
        uGender,
        uPronouns,
        uBirthdate,
        uImg,
      },
      currentAccountDetails
    );
    if (userInputSameNoChange) {
      return NextResponse.json(
        { message: "No changes were made" },
        { status: 400 }
      );
    }

    // is new username already used on another account?
    if (currentAccountDetails.uName !== uName) {
      const usernameAlreadyUsed = await Users.findOne({ uName: uName });
      if (usernameAlreadyUsed) {
        return NextResponse.json(
          { message: "Username already used on another account" },
          { status: 400 }
        );
      }
    }

    // is new email already used on another account?
    if (currentAccountDetails.uEmail !== uEmail) {
      const emailAlreadyUsed = await Users.findOne({ uEmail: uEmail });
      if (emailAlreadyUsed) {
        return NextResponse.json(
          { message: "Email already used on another account" },
          { status: 400 }
        );
      }
    }

    const updateUsers = await Users.findOneAndUpdate(
      { uEmail: email },
      {
        uEmail,
        uName,
        uFName,
        uLName,
        uGender,
        uPronouns,
        uBirthdate,
        uImg,
      },
      { new: true }
    );
    if (!updateUsers) {
      return NextResponse.json({ message: "User not found" }, { status: 404 });
    }
    return NextResponse.json(updateUsers, { status: 200 });
  } catch (error) {
    console.log("ERROR IN USERS PATCH", error);
    return NextResponse.json(
      { message: `Failed to update user` },
      { status: 500 }
    );
  }
};

export const DELETE = async (NextRequest, { params }) => {
  const email = params.email;
  console.log("email: ", email);
  try {
    await connectToDatabase();
    const userExist = await Users.findOne({ uEmail: email });

    const deleteUser = await Users.findOneAndDelete({
      uEmail: email,
    });
    if (!deleteUser) {
      return NextResponse.json({ message: "User not found" }, { status: 404 });
    }
    return NextResponse.json({ message: "User deleted" }, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      { message: `Failed to delete user` },
      { status: 500 }
    );
  }
};
