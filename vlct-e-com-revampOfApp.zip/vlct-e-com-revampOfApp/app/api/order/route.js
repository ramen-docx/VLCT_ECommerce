import connectToDatabase from "@/utils/database";
import Orders from "@/models/orders";
import { NextRequest, NextResponse } from "next/server";

export const GET = async (NextRequest) => {
  try {
    await connectToDatabase();
    const orders = await Orders.find();
    return NextResponse.json(orders, { status: 200 });
  } catch (error) {
    console.log(error);
    return NextResponse.json("Failed to get orders", { status: 500 });
  }
};

export const POST = async (NextRequest) => {
  try {
    await connectToDatabase();
    const ordersData = await NextRequest.json();

    // Validate ordersData here if needed

    const newOrders = await Orders.create(ordersData);
    return NextResponse.json({ newOrders }, { status: 200 });
  } catch (error) {
    console.error("Error creating new order:", error);
    return NextResponse.json(
      { message: `Failed to create new order: ${error.message}` },
      { status: 500 }
    );
  }
};
