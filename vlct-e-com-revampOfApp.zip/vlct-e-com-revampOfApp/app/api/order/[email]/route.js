import connectToDatabase from "@/utils/database";
import Orders from "@/models/orders";
import { NextRequest, NextResponse } from "next/server";

export const GET = async (NextRequest, { params }) => {
  const email = params.email;
  console.log(email);

  try {
    await connectToDatabase();

    const orders = await Orders.find({ orderOwner: email });

    if (!orders || orders.length === 0) {
      return NextResponse.json({ message: false }, { status: 200 });
    }

    return NextResponse.json({ orders }, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      { message: "Error while fetching orders" },
      { status: 501 }
    );
  }
};
export const PATCH = async (NextRequest, { params }) => {
  const email = params.email; // Assuming orderId is the correct parameter

  try {
    await connectToDatabase();
    const { orderStatus } = await NextRequest.json();

    // Fetch current order details
    const currentOrder = await Orders.findById(email);
    if (!currentOrder) {
      return NextResponse.json({ message: "Order not found" }, { status: 404 });
    }

    // Check if the new orderStatus is the same as the current one
    if (currentOrder.orderStatus === orderStatus) {
      return NextResponse.json(
        { message: "No changes were made" },
        { status: 400 }
      );
    }

    // Update orderStatus
    const updatedOrder = await Orders.findByIdAndUpdate(
      email,
      { orderStatus },
      { new: true }
    );

    if (!updatedOrder) {
      return NextResponse.json({ message: "Order not found" }, { status: 404 });
    }

    return NextResponse.json(updatedOrder, { status: 200 });
  } catch (error) {
    console.log("ERROR IN ORDER PATCH", error);
    return NextResponse.json(
      { message: "Failed to update order status" },
      { status: 500 }
    );
  }
};

export const DELETE = async (NextRequest, { params }) => {
  // get the id from the params
  const email = params.email;
  try {
    await connectToDatabase();
    const deletedOrders = await Orders.findByIdAndDelete(email);
    if (!deletedOrders) {
      return NextResponse.json("Order not found", { status: 404 });
    }
    return NextResponse.json(deletedOrders, { status: 200 });
  } catch (error) {
    console.log(error);
    return NextResponse.json("Failed to delete Order", {
      status: 500,
    });
  }
};
