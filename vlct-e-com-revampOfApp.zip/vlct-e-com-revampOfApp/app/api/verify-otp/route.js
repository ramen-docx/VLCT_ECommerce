import nodemailer from "nodemailer";
import connectToDatabase from "@/utils/database";
import Users from "@/models/users";
import { NextRequest, NextResponse } from "next/server";
import { redirect } from "next/navigation";

// export default async function handler(req, res) {
//   const otpData = req.json()

//   try {
//     await connectToDatabase();

//     if (req.method === "POST") {
//       // Verify OTP
//       const { enteredOtp } = req.body;

//       const user = await Users.findOne({ uEmail: email });

//       if (!user) {
//         return res.status(404).json({ message: "User not found" });
//       }

//       const storedOtp = req.session.otp;

//       if (
//         !storedOtp ||
//         storedOtp.email !== email ||
//         storedOtp.otp !== enteredOtp
//       ) {
//         return res.status(400).json({ message: "Incorrect OTP" });
//       }

//       // Clear the OTP from the session
//       delete req.session.otp;

//       // Respond with success message
//       return res.status(200).json({ message: "OTP verified successfully" });
//     } else if (req.method === "GET") {
//       // This part was removed to focus on the OTP verification functionality

//       return res.status(405).json({ message: "Method Not Allowed" });
//     }
//   } catch (error) {
//     console.error("Error:", error);
//     return res.status(500).json({ message: "Internal Server Error" });
//   }
// }

export const POST = async (NextRequest) => {
  try {
    const otpData = await NextRequest.json();
    const existingUser = await Users.findOne({ uEmail: otpData.email });

    if (existingUser && existingUser.otp == otpData.otp) {
      return NextResponse.json({ message: "success" }, { status: 200 });
    }

    return NextResponse.json(
      { message: "Incorrect OTP. Please try again." },
      { status: 400 }
    );
  } catch (error) {
    console.log("Error verifying OTP:", error);
    return NextResponse.json(
      { message: "Failed to verify OTP. Please try again." },
      { status: 500 }
    );
  }
};
