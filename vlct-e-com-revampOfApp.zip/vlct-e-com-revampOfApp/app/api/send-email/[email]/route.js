import connectToDatabase from "@/utils/database";
import { NextRequest, NextResponse } from "next/server";
import nodemailer from "nodemailer";
import Users from "@/models/users";

export const GET = async (req, { params }) => {
  const email = params.email;

  try {
    await connectToDatabase();

    const user = await Users.findOne({ uEmail: email });

    if (!user) {
      return NextResponse.json(
        { message: "User doesn't exist. Please create an account first." },
        { status: 404 }
      );
    }

    return NextResponse.json({ exists: true }, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      { message: "Error while checking if the user exists." },
      { status: 500 }
    );
  }
};

export const POST = async (req, { params }) => {
  const email = params.email;

  try {
    const otp = Math.floor(1000 + Math.random() * 9000); // Generate random 4-digit OTP

    const updatedUser = await Users.findOneAndUpdate(
      { uEmail: email },
      { $set: { otp: otp.toString() } }, // Convert OTP to string for storage
      { new: true } // Return the updated document
    );

    if (!updatedUser) {
      return NextResponse.json(
        { message: "User doesn't exist. Please create an account first." },
        { status: 404 }
      );
    }

    const transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 465,
      secure: true,
      auth: {
        user: "vlctapparelco@gmail.com",
        pass: "vtbolotfbqzjdwhf",
      },
    });

    // send mail with defined transport object
    const info = await transporter.sendMail({
      from: "vlctapparelco@gmail.com",
      to: email,
      subject: "Password Reset",
      text: `Your OTP for password reset is: ${otp}`,
      html: `<p>Your OTP for password reset is: <b>${otp}</b></p>`, // Include OTP in the HTML content
    });

    console.log("Message sent: %s", info.messageId);

    return NextResponse.json(
      { alert: "Email sent successfully." },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error occurred while sending email:", error);
    return NextResponse.json(
      { alert: "Error sending email." },
      { status: 500 }
    );
  }
};
