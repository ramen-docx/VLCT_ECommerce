import connectToDatabase from "@/utils/database";
import { NextRequest, NextResponse } from "next/server";
import nodemailer from "nodemailer";
import Users from "@/models/users";

export const POST = async (NextRequest) => {
  // const email = params.email;
  const { email, otp } = await NextRequest.json();

  try {
    // const otp = Math.floor(1000 + Math.random() * 9000); // Generate random 4-digit OTP

    const transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 465,
      secure: true,
      auth: {
        user: "vlctapparelco@gmail.com",
        pass: "vtbolotfbqzjdwhf",
      },
    });

    // send mail with defined transport object
    const info = await transporter.sendMail({
      from: "vlctapparelco@gmail.com",
      to: email,
      subject: "Verification of Email Address",
      text: `Your OTP for user authentication is: ${otp}`,
      html: `<p>Your OTP for user authentication is: <b>${otp}</b></p>`, // Include OTP in the HTML content
    });

    console.log("Message sent: %s", info.messageId);

    return NextResponse.json(
      { alert: "Check your email, An OTP has been sent for verification." },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error occurred while sending email:", error);
    return NextResponse.json(
      { alert: "Error sending email." },
      { status: 500 }
    );
  }
};
