import connectToDatabase from "@/utils/database";
import Products from "@/models/products";
import { NextRequest, NextResponse } from "next/server";

export const GET = async (NextRequest, { params }) => {
  const id = params.id;
  await connectToDatabase();
  try {
    const products = await Products.findById(id);
    if (!products) {
      return NextResponse.json("Products not found", { status: 404 });
    }
    return NextResponse.json({ products }, { status: 200 });
  } catch (error) {
    console.log(error);
    return NextResponse.json("Failed to get Products", {
      status: 500,
    });
  }
};

export const PATCH = async (NextRequest, { params }) => {
  // get the id from the params
  const id = params.id;

  function isUserDataUnchanged(userInput, currentData) {
    // Compare the other fields
    const isUnchanged =
      userInput.prdName === currentData.prdName &&
      userInput.prdDescription === currentData.prdDescription &&
      userInput.prdPrice === currentData.prdPrice &&
      userInput.prdCategory === currentData.prdCategory &&
      userInput.prdImage === currentData.prdImage &&
      userInput.fbLink === currentData.fbLink &&
      userInput.tiktokLink === currentData.tiktokLink &&
      userInput.instaLinks === currentData.instaLinks;

    // Compare the prdAvailability arrays
    if (
      userInput.prdAvailability.length !== currentData.prdAvailability.length
    ) {
      return false;
    }

    for (let i = 0; i < userInput.prdAvailability.length; i++) {
      const userInputItem = userInput.prdAvailability[i];
      const currentItem = currentData.prdAvailability[i];

      if (
        userInputItem.color !== currentItem.color ||
        JSON.stringify(userInputItem.sizes || {}) !==
          JSON.stringify(currentItem.sizes || {})
      ) {
        return false;
      }
    }

    return isUnchanged;
  }

  try {
    await connectToDatabase();
    console.log("=============================================");
    const currentProductData = await Products.findById(id);
    const userInputProductsData = await NextRequest.json();
    console.log(currentProductData);
    console.log(userInputProductsData);
    console.log(id);
    // Checkers =====================================================================================================
    // is user input the same as the current data
    const isUserDataSameWithDb = isUserDataUnchanged(
      userInputProductsData,
      currentProductData
    );
    if (isUserDataSameWithDb) {
      return NextResponse.json(
        { message: "No changes detected" },
        { status: 400 }
      );
    }

    // is the product name already taken
    if (currentProductData.prdName !== userInputProductsData.prdName) {
      const productExists = await Products.findOne({
        prdName: userInputProductsData.prdName,
      });
      if (productExists) {
        return NextResponse.json(
          { message: "Product name is already taken" },
          { status: 400 }
        );
      }
    }

    // checker success
    const updatedProducts = await Products.findByIdAndUpdate(
      id,
      userInputProductsData,
      { new: true }
    );
    if (!updatedProducts) {
      return NextResponse.json(
        { message: "Product not found" },
        { status: 404 }
      );
    }
    return NextResponse.json(updatedProducts, { status: 200 });
  } catch (error) {
    console.log(error);
    return NextResponse.json(
      { message: `Failed to update product` },
      { status: 500 }
    );
  }
};

export const DELETE = async (NextRequest, { params }) => {
  // get the id from the params
  const id = params.id;
  try {
    await connectToDatabase();
    const deletedProducts = await Products.findByIdAndDelete(id);
    if (!deletedProducts) {
      return NextResponse.json("Product not found", { status: 404 });
    }
    return NextResponse.json(deletedProducts, { status: 200 });
  } catch (error) {
    console.log(error);
    return NextResponse.json("Failed to delete product", {
      status: 500,
    });
  }
};
