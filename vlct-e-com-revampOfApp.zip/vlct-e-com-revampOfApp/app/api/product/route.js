import connectToDatabase from "@/utils/database";
import Products from "@/models/products";
import { NextRequest, NextResponse } from "next/server";

export const GET = async (NextRequest) => {
  try {
    await connectToDatabase();
    const products = await Products.find();
    return NextResponse.json(products, { status: 200 });
  } catch (error) {
    console.log(error);
    return NextResponse.json("Failed to get product", { status: 500 });
  }
};

export const POST = async (NextRequest) => {
  try {
    await connectToDatabase();
    const productsData = await NextRequest.json();
    const prdName = productsData.prdName;
    // checker =====================================================================================================
    // product Checker
    const productExists = await Products.findOne({
      prdName: prdName,
    });
    console.log(productExists, "productExists");
    if (productExists) {
      return NextResponse.json(
        { message: "Product already exists." },
        { status: 400 }
      );
    }
    const newProducts = await Products.create(productsData);
    return NextResponse.json({ newProducts }, { status: 200 });
  } catch (error) {
    console.log("ERROR IN USERS PATCH", error);
    return NextResponse.json(
      { message: `Failed to update products` },
      { status: 500 }
    );
  }
};
