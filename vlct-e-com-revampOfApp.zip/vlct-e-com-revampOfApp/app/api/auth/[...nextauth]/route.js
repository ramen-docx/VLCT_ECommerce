import connectToDatabase from "@/utils/database";
import Users from "@/models/users";

//react things
import NextAuth from "next-auth/next";
import GoogleProvider from "next-auth/providers/google";
import CredentialsProvider from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";

export const authOptions = {
  pages: {
    signIn: "/login",
  },
  providers: [
    CredentialsProvider({
      name: "credentials",
      credentials: {
        email: { label: "Email", type: "text" },
        password: { label: "Password", type: "password" },
      },
      authorization: {
        params: {
          access_type: "offline",
          prompt: "consent",
          include_granted_scopes: "true",
        },
      },

      async authorize(credentials) {
        const { email, password } = credentials;

        try {
          await connectToDatabase();
          const usersData = await Users.findOne({
            $or: [{ uEmail: email }, { uName: email }],
          });

          if (!usersData) {
            return null;
          }

          const passwordsMatch = await bcrypt.compare(
            password,
            usersData.uPassword
          );

          if (!passwordsMatch) {
            return null;
          }
          console.log(
            "=========================================== Users Data ==============================="
          );
          console.log("users Data: ", usersData);

          // Return the user
          return {
            id: usersData._id,
            name: usersData.uName || "",
            email: usersData.uEmail,
            image: usersData.uImg || "",
          };
        } catch (error) {
          console.log("Error: ", error);
        }
      },
    }),
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      authorization: {
        params: {
          access_type: "offline",
          prompt: "consent",
          include_granted_scopes: "true",
        },
      },
    }),
  ],
  callbacks: {
    async signIn({ user, account, profile }) {
      console.log(
        "=========================================== SignIn callback ==============================="
      );
      // ======================= Google =======================
      if (account.provider === "google") {
        console.log(
          "=========================================== Google ==============================="
        );
        const { name, email } = user;
        try {
          await connectToDatabase();
          const userExists = await Users.findOne({ uEmail: email });

          let role;
          if (email === process.env.ADMIN_EMAIL) {
            role = "admin";
          }

          if (!userExists) {
            const newUser = new Users({
              uEmail: email,
              uFName: profile.given_name,
              uLName: profile.family_name,
              uImage: profile.picture,
              uRole: role || "customer",
              uImg: profile.picture,
            });

            await newUser.save();
            console.log("User saved successfully");
          }
        } catch (error) {
          console.log(error);
        }
      }

      // ======================= Credentials =======================
      if (account.provider === "credentials") {
        console.log(
          "=========================================== Credentials ==============================="
        );
      }

      return user;
    },
  },
  session: {
    strategy: "jwt",
  },
  secret: process.env.NEXTAUTH_SECRET,
};

const handler = NextAuth(authOptions);

export { handler as GET, handler as POST };
