import connectToDatabase from "@/utils/database";
import Users from "@/models/users";
import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";

// export const GET = async (NextRequest, { params }) => {
//   // const email = params.email;
//   // try {
//   //   const userDetails = await Users.findOne({ uEmail: email });
//   //   if (!userDetails) {
//   return NextResponse.json({ message: "hello" }, { status: 200 });
//   //   }
//   //   if (!userDetails.uPassword) {
//   //     return NextResponse.json(
//   //       { hasPassword: false },
//   //       { message: "User has no password" },
//   //       { status: 404 }
//   //     );
//   //   }
//   //   return NextResponse.json({ hasPassword: true }, { status: 200 });
//   // } catch (error) {
//   //   return NextResponse.json(
//   //     { message: "Error while fetching user's account and password" },
//   //     { status: 501 }
//   //   );
//   // }
// };

export const PATCH = async (NextRequest) => {
  const changePasswordData = await NextRequest.json();
  const newPassword = changePasswordData.uPassword;
  const email = changePasswordData.email;

  try {
    await connectToDatabase();
    const user = await Users.findOne({ uEmail: email });

    if (!user) {
      return NextResponse.json({ message: "User not found", status: 404 });
    }
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.uPassword = hashedPassword;
    await user.save();
    return NextResponse.json({
      message: "Password updated successfully",
      status: 200,
    });
  } catch (error) {
    console.error("Error updating password:", error);
    return NextResponse.json({
      message: "Failed to update password",
      status: 500,
    });
  }
};
// const passwordRegex =
//   /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*(),.?":{}|<>])[A-Za-z\d!@#$%^&*(),.?":{}|<>]{8,}$/;
// const passwords = await NextRequest.json();

//   if (passwords.oldPassword) {
//     const passwordsMatch = await bcrypt.compare(
//       passwords.oldPassword,
//       currentAccountDetails.uPassword
//     );
//     if (!passwordsMatch) {
//       return NextResponse.json(
//         { message: "Old password is incorrect" },
//         { status: 400 }
//       );
//     }
//     if (passwords.oldPassword === passwords.newPassword) {
//       return NextResponse.json(
//         { message: "New password cannot be the same as old password" },
//         { status: 400 }
//       );
//     }
//   }

//   if (!passwordRegex.test(passwords.newPassword)) {
//     return NextResponse.json(
//       {
//         message:
//           "Password should have at least one uppercase and lowercase letter, one digit, and one special character. Minimum of 8 characters",
//       },
//       { status: 400 }
//     );
//   }

//   if (passwords.newPassword !== passwords.confirmPassword) {
//     return NextResponse.json(
//       { message: "Passwords do not match" },
//       { status: 400 }
//     );
//   }
//   const encryptedPassword = await bcrypt.hash(passwords.newPassword, 10);

//   const saveNewPassword = await Users.findOneAndUpdate(
//     { uEmail: email },
//     { uPassword: encryptedPassword },
//     { new: true }
//   );
//   console.log("saveNewPassword: ", saveNewPassword);
//   if (!saveNewPassword) {
//     return NextResponse.json(
//       { message: "Password failed to save" },
//       { status: 404 }
//     );
//   }

//   return NextResponse.json({ saveNewPassword }, { status: 200 });
// } catch (error) {
//   return NextResponse.json(
//     { message: "Error while Saving Password" },
//     { status: 501 }
//   );
// }
// };
