import connectToDatabase from "@/utils/database";
import Carts from "@/models/cart";
import { NextRequest, NextResponse } from "next/server";

export const GET = async (NextRequest) => {
  try {
    await connectToDatabase();
    const carts = await Carts.find();
    return NextResponse.json(carts, { status: 200 });
  } catch (error) {
    console.log(error);
    return NextResponse.json("Failed to get cart", { status: 500 });
  }
};

export const POST = async (NextRequest) => {
  try {
    await connectToDatabase();
    const cartsData = await NextRequest.json();
    const newCart = [
      {
        prdID: cartsData.item.prdID,
        prdName: cartsData.item.prdName,
        prdPrice: cartsData.item.prdPrice,
        prdImage: cartsData.item.prdImage,
        prdQuantity: cartsData.item.prdQuantity,
      },
    ];
    const newCarts = await Carts.create(cartsData);
    return NextResponse.json({ newCarts }, { status: 200 });
  } catch (error) {
    console.log("ERROR IN USERS PATCH", error);
    return NextResponse.json(
      { message: `Failed to update cart` },
      { status: 500 }
    );
  }
};
