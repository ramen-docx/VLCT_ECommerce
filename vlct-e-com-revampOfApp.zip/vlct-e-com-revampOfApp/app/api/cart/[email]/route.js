import connectToDatabase from "@/utils/database";
import Products from "@/models/products";
import Carts from "@/models/cart";
import { NextRequest, NextResponse } from "next/server";

export const GET = async (NextRequest, { params }) => {
  const email = params.email;

  // palagi yung params.<?> is yung name nung folder na gagawing param
  try {
    await connectToDatabase();

    const carts = await Carts.findOne({ cartOwner: email });
    // select("-<table header shiz>") is to exclude shizz from the response

    if (!carts) {
      return NextResponse.json({ message: false }, { status: 200 });
    }

    return NextResponse.json({ carts }, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      { message: "Error while fetching users" },
      { status: 501 }
    );
  }
};

export const PATCH = async (NextRequest, { params }) => {
  const email = params.email;

  try {
    await connectToDatabase();
    const cartData = await NextRequest.json();

    const updatedCart = await Carts.findOneAndUpdate(
      { cartOwner: email },
      {
        $set: {
          item: cartData.item,
        },
      },
      { new: true }
    );

    console.log(updatedCart, "updatedCart============================");

    return NextResponse.json({ updatedCart }, { status: 200 });
  } catch (error) {
    console.log(error);
    return NextResponse.json(
      { message: "Error while updating cart" },
      { status: 501 }
    );
  }
};
export const DELETE = async (NextRequest, { params }) => {
  // get the id from the params
  const email = params.email;
  try {
    await connectToDatabase();
    const deletedItem = await Carts.findOneAndDelete(email);
    if (!deletedItem) {
      return NextResponse.json("Item not found", { status: 404 });
    }
    return NextResponse.json(deletedItem, { status: 200 });
  } catch (error) {
    console.log(error);
    return NextResponse.json("Failed to delete Cart Item", {
      status: 500,
    });
  }
};
