// /api/password-reset.js
import nodemailer from "nodemailer";
import connectToDatabase from "@/utils/database";
import Users from "@/models/users";

export default async function handler(req, res) {
  const { email } = req.query;

  try {
    await connectToDatabase();

    if (req.method === "POST") {
      // Generate and send OTP via email
      const otp = Math.floor(1000 + Math.random() * 9000); // Generate random 4-digit OTP

      const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 465,
        secure: true,
        auth: {
          user: "vlctapparelco@gmail.com",
          pass: "vtbolotfbqzjdwhf",
        },
      });

      const info = await transporter.sendMail({
        from: "vlctapparelco@gmail.com",
        to: email,
        subject: "Password Reset OTP",
        text: `Your OTP for password reset is: ${otp}`,
      });

      console.log("Message sent: %s", info.messageId);

      // Store OTP in the session
      req.session.otp = { email, otp };

      // Respond with success message
      return res.status(200).json({ message: "OTP sent successfully" });
    } else {
      return res.status(405).json({ message: "Method Not Allowed" });
    }
  } catch (error) {
    console.error("Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
}
