"use client";
import styles from "@/styles/register.module.css";
import React, { useState } from "react";
import axios from "axios";
import { useSearchParams } from "next/navigation";
import { useRouter } from "next/navigation";

function ChangePassword() {
  const searchParams = useSearchParams();
  const { push } = useRouter();

  const email = searchParams.get("email");

  const [otp, setOtp] = useState("");

  const handleOtpChange = (e) => {
    const value = e.target.value;
    if (/^\d*$/.test(value) && value.length <= 4) {
      setOtp(value);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const otpData = {
      otp: otp,
      email: email,
    };
    axios.post("/api/verify-otp", otpData).then((res) => {
      console.log(res.data);
      push(`/changepasswordotp?email=${email}`);
    });
    // .then((res) => {
    //   // alert("OTP verified successfully");
    //   console.log(res.data)
    //   // Add redirection logic or any other action upon successful OTP verification
    // })
    // .catch((error) => {
    //   console.error("Error verifying OTP:", error);
    //   alert("Failed to verify OTP. Please try again.");
    // });
  };

  const handleResendEmail = () => {
    // Add logic to resend the email
    alert("Resend email functionality not implemented yet.");
  };

  return (
    <div className={styles.bgImage}>
      <div className={`${styles.loginBox} container text-center my-5`}>
        <div className="register-container mx-md-5">
          <div className="register_group">
            <br />
            <div className="fs-4 mb-3">Enter OTP Code</div>
            <form onSubmit={handleSubmit}>
              <div className="d-flex justify-content-center">
                <div className="form-floating mb-3 mx-1 col-4">
                  <input
                    type="text"
                    id="otp"
                    name="otp"
                    inputMode="numeric"
                    required
                    maxLength={4}
                    placeholder="Enter OTP"
                    value={otp}
                    onChange={handleOtpChange}
                    className="form-control text-center fs-1 p-1"
                  />
                </div>
              </div>
              <div className="p mb-3">
                We have sent you an OTP to your email.
              </div>
              <br />
              <button
                className={`${styles.loginbutton} btn btn-light login-button mb-2`}
                type="submit"
              >
                Verify
              </button>
            </form>
            <button
              type="button"
              className={`${styles.cancelbutton} btn btn-light login-button mb-2`}
              onClick={handleResendEmail}
            >
              Resend Email
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ChangePassword;
