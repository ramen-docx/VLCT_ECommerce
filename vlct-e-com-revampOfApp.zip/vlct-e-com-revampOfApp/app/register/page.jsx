"use client";
import { useEffect } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import RegistrationForm from "@/components/RegistrationForm";

export default function Register() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const loading = status === "loading";

  useEffect(() => {
    if (typeof window !== "undefined" && session) {
      router.push("/"); // Redirect to homepage if session exists
    }
  }, [session]);

  if (loading) {
    return null;
  } else {
    return <RegistrationForm />;
  }
}
