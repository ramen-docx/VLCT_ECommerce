import React from "react";
import styles from "@/styles/faqs.module.css";

function Faqs() {
  return (
    <>
      <div className={styles.bgImage}>
        <div className="d-flex justify-content-center text-center mt-4 text-light">
          <h1>FREQUENTLY ASKED QUESTIONS</h1>
        </div>
        <div className="d-flex justify-content-center">
          <div className={styles.faqs}>
            <div className="d-flex flex-column text-justify text-light px-3 pt-3">
              <div className={styles.faqsContent}>
                <div className={`${styles.questionTextFormat} px-5`}>
                Do you accept same day delivery?
                  <p className={styles.ansTextFormat}>
                  Yes, we offer Same Day Delivery via Grab, Lalamove, or your preferred courier (Shipping Fee upon booking).

                  </p>
                </div>

                <div className={`${styles.questionTextFormat} px-5`}>
                How many days does it take to ship packages and how much?
                  <p className={styles.ansTextFormat}>
                  Standard Shipping via J&T:<br></br>
                  Metro Manila: 1-3 days - ₱100<br></br>
                  Luzon: 1-5 days - ₱110<br></br>
                  Visayas: 3-7 days - ₱115<br></br>
                  Mindanao: 3-7 days - ₱120
                  </p>
                </div>

                <div className={`${styles.questionTextFormat} px-5`}>
                Do you offer customization or personalization options?
                  <p className={styles.ansTextFormat}>
                  Absolutely! Feel free to contact us directly on any platform, and we can discuss customization options.

                  </p>
                </div>

                <div className={`${styles.questionTextFormat} px-5`}>
                Can I cancel or modify my order after it's been placed?
                  <p className={styles.ansTextFormat}>
                  Unfortunately, orders cannot be canceled once checkout is complete. However, you can modify your order by messaging us as soon as possible.
                  </p>
                </div>

                <div className={`${styles.questionTextFormat} px-5`}>
                What payment methods do you accept?
                  <p className={styles.ansTextFormat}>
                  We accept Gcash, BDO, and GoTyme Bank Transfer.
                  </p>
                </div>

                <div className={`${styles.questionTextFormat} px-5`}>
                What is your return/exchange policy?
                  <p className={styles.ansTextFormat}>
                  Regrettably, we are unable to accept returns or exchanges. Prior to shipping, we meticulously inspect each item to ensure it is complete, secure, and meets our quality standards.
                  </p>
                </div>

                <div className={`${styles.questionTextFormat} px-5`}>
                How do I care for my garments?

                  <p className={styles.ansTextFormat}>
                  Machine Wash Cold: Preserve colors and prevent shrinkage by washing garments in cold water.
                  Gentle Cycle: Use a gentle cycle to avoid stretching or damaging delicate fabrics.<br></br>
                  Use Mild Detergent: Opt for a mild detergent to avoid harsh chemicals that can damage fabrics.
                  Avoid Bleach: Bleach can weaken fibers and cause discoloration, so it's best to avoid it.<br></br>
                  Air Dry or Low Heat: Preserve elasticity and prevent shrinking by air drying whenever possible. If using a dryer, use a low heat setting.<br></br>
                  Iron with Caution: To avoid scorching or damaging delicate fabrics, iron clothing inside out on low heat.
                  Store Properly: Hang clothing to prevent wrinkles, or fold neatly to avoid creasing. Store in a cool, dry place away from direct sunlight.<br></br>
                  Handle with Care: Prevent stretching or tearing of fabrics by avoiding rough handling or excessive pulling.
                  </p>
                </div>

              
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Faqs;
