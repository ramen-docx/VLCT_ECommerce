import { Schema, model, models } from "mongoose";
import mongoose from "mongoose";

const userSchema = mongoose.Schema({
  uName: {
    //1
    type: String,
    sparse: [true, "Username is already taken"],
  },
  uEmail: {
    //2
    type: String,
    required: [true, "Please provide an email address."],
    unique: [true, "email address is already taken"],
  },
  uPassword: {
    //3
    type: String,
  },
  uFName: {
    //4
    type: String,
  },
  uLName: {
    //5
    type: String,
  },
  uGender: {
    //6
    type: String,
  },
  uBirthdate: {
    //7
    type: String,
  },
  uPronouns: {
    //8
    type: String,
  },
  otp: {
    //8
    type: String,
  },
  uImg: {
    //9
    type: String,
  },
  uRole: {
    //10
    type: String,
    enum: ["customer", "admin"], // customer or admin
    default: "customer",
  },
  uContactNum: {
    type: String,
  },
});

const User = models.User || model("User", userSchema);
export default User;
