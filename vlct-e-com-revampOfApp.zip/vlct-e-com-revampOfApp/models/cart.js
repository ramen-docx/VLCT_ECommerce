import { Schema, model, models } from "mongoose";

const CartsSchema = new Schema({
  cartOwner: {
    type: String,
  },
  item: {
    type: Object,
  },
});

const Carts = models.Carts || model("Carts", CartsSchema);

export default Carts;
