import { Schema, model, models } from "mongoose";

const OrdersSchema = new Schema({
  orderOwner: {
    //kung sino bumili
    type: String,
  },
  customerName: {
    type: String,
  },
  items: {
    type: Object,
  },
  paymentMethod: {
    type: String,
  },
  transReceipt: {
    type: String,
  },
  address: {
    type: String,
  },
  contactNum: {
    type: Number,
  },
  totalPrice: {
    type: Number,
  },
  paymentReferenceNum: {
    type: String,
  },
  orderStatus: {
    type: String,
    enum: ["pending", "processing", "shipped", "delivered"],
    default: "pending",
  },
  orderDate: {
    type: Date,
    default: Date.now, // Default value will be the current date and time
  },
});

const Orders = models.Orders || model("Orders", OrdersSchema);

export default Orders;
