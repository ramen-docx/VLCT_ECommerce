import { Schema, model, models } from "mongoose";

const ProductsSchema = new Schema({
  prdName: {
    type: String,
  },
  prdPrice: {
    type: Number,
  },
  prdCategory: {
    type: String,
  },
  prdDescription: {
    type: String,
  },
  prdAvailability: {
    type: Object,
  },
  fbLink: {
    type: String,
  },
  tiktokLink: {
    type: String,
  },
  instaLinks: {
    type: String,
  },
  prdImage: {
    type: String,
  },
  prdHide: {
    type: Boolean,
    default: false,
  },
});

const Products = models.Products || model("Products", ProductsSchema);

export default Products;
