"use client";
import styles from "@/styles/register.module.css";
import "bootstrap/dist/css/bootstrap.min.css";

// react imports
import React from "react";
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useRouter } from "next/navigation";
import axios from "axios";
import Link from "next/link";
import RegistrationOTP from "./regotp";
import DataPrivacyModal from "./DataPrivacyModal";

function RegistrationForm() {
  const [error, setError] = useState(null);
  const [otp, setOtp] = useState();
  const [showModal, setShowModal] = useState(false);
  const [registrationData, setRegistrationData] = useState();

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm();

  const handleRegister = (data) => {
    console.log("open modal?", !error);
    console.log("error", error);
    Promise.all([axios.post("/api/usernameExist", data)])
      .then(() => {
        setShowModal(true);
        console.log(showModal);
        setRegistrationData(data);
        generateOtpAndSendVerificationEmail(data);
      })
      .catch((error) => {
        console.error("Error checking if username exists:", error);
        setError(error.response.data.message);
      });
  };

  const validateEmail = (value) => {
    // Regular expression for email validation
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!value.match(emailRegex)) {
      setError("Invalid email address");
      return false;
    }
    return true;
  };

  const generateOtpAndSendVerificationEmail = (data) => {
    const otp = Math.floor(1000 + Math.random() * 9000);
    setOtp(otp);
    if (otp && data.uEmail) {
      axios
        .post("/api/verif-email", { email: data.uEmail, otp })
        .then((res) => {
          console.log(res.data.alert);
        })
        .catch((error) => {
          console.error("Error sending verification email:", error);
        });
    }
  };

  const handleTermsAcceptance = () => {
    setTermsAccepted(true);
  };

  return (
    <>
      <div className={styles.bgImage}>
        <div className={`${styles.loginBox} container text-center my-5`}>
          <div className="register-container mx-md-5">
            <div className="register_group">
              <br />
              <h2 className="mb-1">REGISTER</h2>

              {error && <div className="alert alert-danger">{error}</div>}

              <form onSubmit={handleSubmit(handleRegister)}>
                <div className="form-floating mb-3 mt-5 mx-3">
                  <input
                    type="text"
                    id="username"
                    name="username"
                    required
                    placeholder="Username"
                    className="form-control"
                    {...register("uName")}
                  />
                  <label htmlFor="floatingInput">Username</label>
                </div>

                <div className="form-floating mb-3 mx-3">
                  <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    placeholder="Email"
                    className={`form-control ${
                      errors.uEmail ? "is-invalid" : ""
                    }`}
                    {...register("uEmail", {
                      required: true,
                      validate: validateEmail,
                    })}
                  />
                  <label htmlFor="floatingInput">Email</label>
                </div>

                <div className="form-floating mb-3 mx-3">
                  <input
                    type="password"
                    id="password"
                    name="password"
                    required
                    placeholder="Password"
                    className="form-control"
                    {...register("uPassword")}
                  />
                  <label htmlFor="floatingInput">Password</label>
                </div>

                <div className="form-floating mb-3 mx-3">
                  <input
                    type="password"
                    id="confirmPassword"
                    name="confirmPassword"
                    required
                    placeholder="Confirm Password"
                    className="form-control"
                    {...register("ConfirmPassword")}
                  />
                  <label htmlFor="floatingInput">Confirm Password</label>
                </div>

                <div className="form-floating mb-3 mx-3">
                  <input
                    type="text"
                    id="firstName"
                    name="firstName"
                    required
                    placeholder="First Name"
                    className="form-control"
                    {...register("uFName")}
                  />
                  <label htmlFor="floatingInput">First Name</label>
                </div>

                <div className="form-floating mb-1 mx-3">
                  <input
                    type="text"
                    id="lastName"
                    name="lastName"
                    required
                    placeholder="Last Name"
                    className="form-control"
                    {...register("uLName")}
                  />
                  <label htmlFor="floatingInput">Last Name</label>
                </div>

                <br />

                <p className="">
                  <input
                    type="checkbox"
                    {...register("accepted")}
                    onClick={() => {
                      console.log(watch("accepted"));
                    }}
                  />
                  {""} Accept {""}
                  <a
                    type="button"
                    className="text-decoration-none"
                    data-bs-toggle="modal"
                    data-bs-target="#dataPrivModal"
                  >
                    Terms and Conditions
                  </a>
                </p>

                <button
                  type="submit"
                  className="btn btn-primary mb-3"
                  disabled={!watch("accepted")}
                >
                  Register
                </button>
              </form>

              <Link href="/login" className="nav-link text-primary">
                Back to Login Page
              </Link>
              <br />
            </div>
          </div>
        </div>
      </div>

      <DataPrivacyModal onAccept={handleTermsAcceptance} />

      <RegistrationOTP
        showModal={showModal}
        setShowModal={setShowModal}
        otp={otp}
        registrationData={registrationData}
        setError={setError}
      />
    </>
  );
}

export default RegistrationForm;
