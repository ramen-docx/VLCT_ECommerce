"use client";
import styles from "@/styles/product.module.css";
import React from "react";
import Link from "next/link";

import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useRouter } from "next/navigation";
import { signOut, useSession } from "next-auth/react";
import axios from "axios";
import { set } from "mongoose";

function ProductView({ setProducts, productID, content }) {
  const [items, setItem] = useState([]);
  const [quantity, setQuantity] = useState();
  const [selectedColor, setSelectedColor] = useState("");
  const [cartItems, setCartItems] = useState([]);
  const [selectedSizes, setSelectedSizes] = useState([]);
  const { data: session, status } = useSession();
  const router = useRouter();
  const {
    register,
    handleSubmit,
    watch,
    reset,
    setValue,
    formState: { errors },
  } = useForm({
    defaultValues: {
      quantityBought: 1,
    },
  });

  const quantityAddHandler = () => {
    const currentQuantity = parseInt(watch("quantityBought"));
    console.log();

    const selectedSizeStock = selectedSizes.find(
      ([size]) => size === watch("sizeBought")
    )[1];

    const updatedQuantity = Math.min(currentQuantity + 1, selectedSizeStock);
    setValue("quantityBought", updatedQuantity);
  };

  const quantityDecrementHandler = () => {
    const currentQuantity = parseInt(watch("quantityBought"));
    setValue("quantityBought", Math.max(currentQuantity - 1, 1));
  };

  // ***** every time the thing inside the bracket changes it runs *****
  useEffect(() => {
    // Check if content and prdAvailability are available
    if (
      content &&
      content.prdAvailability &&
      content.prdAvailability.length > 0
    ) {
      // Set the default color
      const defaultColor = content.prdAvailability[0].color;
      setSelectedColor(defaultColor);
      setValue("colorBought", defaultColor);

      // Find the availability for the default color
      const defaultColorAvailability = content.prdAvailability.find(
        (avail) => avail.color === defaultColor
      );
      console.log("selected sizes : ", defaultColorAvailability.sizes);
      // Set the selected sizes based on the availability for the default color
      if (defaultColorAvailability) {
        setSelectedSizes(Object.entries(defaultColorAvailability.sizes));
      }
    }
  }, [content]); // <------------------------- ***** this bracket *****

  const options = selectedSizes
    .filter(([size, quantity]) => quantity > 0) // Filter out sizes with zero stock
    .map(([size, quantity], index) => (
      <option key={index} value={size}>
        {`${size} (stock: ${quantity})`}
      </option>
    ));

  const handleDismiss = () => {
    reset();
  };

  const resetItem = () => {
    setItem([]);
  };

  const onSubmit = (data) => {
    if (!session) {
      router.push("/login");
    }
    if (session) {
      axios.get(`/api/cart/${session.user.email}`).then((cartRes) => {
        const newItem = {
          prdID: productID,
          prdColor: watch("colorBought"),
          prdSize: watch("sizeBought"),
          prdQuantity: parseInt(watch("quantityBought")),
        };

        // Find the availability for the selected color and size
        const availability = content.prdAvailability.find(
          (avail) => avail.color === newItem.prdColor
        );
        const selectedSizeStock = availability
          ? availability.sizes[newItem.prdSize]
          : 0;

        if (cartRes.data.carts) {
          let itemArray = Array.isArray(cartRes.data.carts.item)
            ? cartRes.data.carts.item
            : [cartRes.data.carts.item];

          // Check if an item with the same prdID, prdColor and prdSize already exists in the cart
          const existingItemIndex = itemArray.findIndex(
            (item) =>
              item.prdID === newItem.prdID &&
              item.prdColor === newItem.prdColor &&
              item.prdSize === newItem.prdSize
          );

          if (existingItemIndex !== -1) {
            // If the item exists, add the quantity but not more than the stock
            const totalQuantity =
              itemArray[existingItemIndex].prdQuantity + newItem.prdQuantity;
            itemArray[existingItemIndex].prdQuantity = Math.min(
              totalQuantity,
              selectedSizeStock
            );
          } else {
            // If the item doesn't exist, add it to the cart
            itemArray.push(newItem);
          }

          const userCartItems = {
            cartOwner: session.user.email,
            item: itemArray,
          };

          axios.patch(`/api/cart/${session.user.email}`, userCartItems);
        } else {
          // If cartRes.data.carts is undefined, add the user's inputs to the database
          const userCartItems = {
            cartOwner: session.user.email,
            item: newItem,
          };

          axios.post("/api/cart", userCartItems);
        }
      });
    }
  };

  return (
    <>
      <div
        className="modal fade"
        id="ProductsView"
        tabIndex="-1"
        aria-labelledby="ProductsView"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-fullscreen">
          <div className="modal-content h6">
            <div className="modal-header bg-white border border-dark">
              <h1
                className="modal-title icon-link fs-5 fw-bold text-dark"
                id="ProductsView"
                data-bs-dismiss="modal"
              >
                Product View
              </h1>
              <button
                type="button"
                className="btn-close bg-light"
                data-bs-dismiss="modal"
                aria-label="Close"
                onClick={handleDismiss}
              ></button>
            </div>
            <div className="modal-body text-start px-0 pb-0 pt-0 bg-dark">
              <div className={styles.bgImage}>
                <div
                  className={`${styles.productcontainer} mt-md-3 mb-md-3 mt-5 mb-5`}
                >
                  <form
                    className={styles.formCorner}
                    onSubmit={handleSubmit(onSubmit)}
                  >
                    <div className="row d-flex justify-content-start">
                      <div className="col-md-6">
                        <div
                          className={`${styles.productimage} d-flex justify-content-md-start justify-content-center`}
                        >
                          <img
                            src={content.prdImage}
                            alt=""
                            width="500"
                            height="500"
                            className={styles.image}
                          />
                        </div>
                      </div>

                      <div className="col-md-6 text-md-start text-center">
                        <div className="text-dark fw-bold fs-2">
                          <label
                            id="prdName"
                            className="justify-content-center text-start mt-3 mt-md-0"
                          >
                            {content.prdName}
                          </label>
                        </div>
                        <div className="row d-flex justify-content-center justify-content-md-start mb-2">
                          <label
                            id="prdCategory"
                            className="justify-content-center text-md-start fw-bold text-dark"
                          >
                            Category: {content.prdCategory}
                          </label>
                        </div>
                        <div className="fs-5 row d-flex justify-content-start mt-md-1">
                          <label
                            id="prdPrice"
                            className="justify-content-center text-md-start fw-bold text-dark"
                          >
                            ₱{content.prdPrice}
                          </label>
                        </div>

                        <hr className="bg-dark border border-dark pb-1" />
                        {content.prdAvailability &&
                          content.prdAvailability.length > 0 && (
                            <>
                              <div className="row d-flex justify-content-center justify-content-md-start mb-2">
                                <label
                                  htmlFor="colorSelector"
                                  className="text-dark fw-bold"
                                >
                                  Select Variant
                                </label>

                                {options.length > 0 ? (
                                  <select
                                    className={`${styles.selectorDesign} form-select form-select-sm w-75 text-center bg-dark text-light ms-2 border border-light shadow-sm`}
                                    aria-label="Size Selector"
                                    id="sizeSelector"
                                    hidden
                                    {...register("sizeBought")}
                                  >
                                    {options}
                                  </select>
                                ) : (
                                  <div>No Stocks Available</div>
                                )}

                                <select
                                  className={`${styles.selectorDesign} form-select form-select-sm w-75 text-center bg-dark text-light ms-2 border border-light shadow-sm`}
                                  aria-label="color Selector"
                                  id="colorSelector"
                                  {...register("colorBought")}
                                >
                                  {content.prdAvailability.map(
                                    (availability, index) => (
                                      <option key={index}>
                                        {availability.color}
                                      </option>
                                    )
                                  )}
                                </select>
                              </div>
                              {content.prdCategory == "Apparel" && (
                                <div className="row d-flex justify-content-center justify-content-md-start">
                                  <label
                                    htmlFor="sizeSelector"
                                    className="text-dark fw-bold"
                                  >
                                    Select Size
                                  </label>
                                  {options.length > 0 ? (
                                    <select
                                      className={`${styles.selectorDesign} form-select form-select-sm w-75 text-center bg-dark text-light ms-2 border border-light shadow-sm`}
                                      aria-label="Size Selector"
                                      id="sizeSelector"
                                      {...register("sizeBought")}
                                    >
                                      {options}
                                    </select>
                                  ) : (
                                    <div>No Stocks Available</div>
                                  )}
                                </div>
                              )}
                            </>
                          )}

                        <div className="row d-flex justify-content-center justify-content-md-start mt-3 ms-md-0">
                          <div className={`${styles.cartQuantity} text-center`}>
                            <label
                              htmlFor="sizeSelector"
                              className="text-dark text-start fw-bold"
                            >
                              Quantity
                            </label>
                            <div className="input-group mb-3 mx-0">
                              <div className="input-group-prepend">
                                <button
                                  className="btn btn-outline-secondary bg-light rounded-0"
                                  type="button"
                                  onClick={quantityDecrementHandler}
                                >
                                  -
                                </button>
                              </div>
                              <input
                                type="text"
                                className="form-control bg-dark text-light border-white rounded-0 fw-bold text-center"
                                id="quantity"
                                value={quantity}
                                disabled
                                {...register("quantityBought")}
                              />
                              <div className="input-group-append">
                                <button
                                  className="btn btn-outline-secondary bg-light rounded-0"
                                  type="button"
                                  onClick={quantityAddHandler}
                                >
                                  +
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="row d-flex justify-content-center justify-content-md-start mt-3 ms-md-0">
                          <button
                            type="submit"
                            data-bs-dismiss="modal"
                            disabled={options.length > 0 ? false : true}
                            className="btn btn-dark w-75 fw-bold text-light"
                          >
                            Add to Cart
                          </button>
                        </div>
                      </div>
                    </div>

                    <div
                      className={`${styles.productdescription} d-flex justify-content-center mt-0 mt-md-2`}
                    >
                      <label>
                        <textarea
                          className="bg-light text-dark shadow-sm"
                          name="postContent"
                          defaultValue={content.prdDescription}
                          id="prdDescription"
                          disabled
                          rows={8}
                          cols={80}
                          style={{ resize: "none" }}
                        />
                      </label>
                    </div>

                    <div className="row d-flex text-center">
                      <div className="col-md-12">
                        {content.fbLink && (
                          <Link
                            href={content.fbLink != null ? content.fbLink : "/"}
                            className={`${styles.badge} badge-success`}
                          >
                            <img
                              src="images/Fb.png"
                              alt="FB Icon"
                              width="30"
                              height="30"
                              className="d-inline-block align-text-top"
                            />
                          </Link>
                        )}
                        {content.tiktokLink && (
                          <Link
                            href={
                              content.tiktokLink != null
                                ? content.tiktokLink
                                : "/"
                            }
                            className={`${styles.badge} badge-success`}
                          >
                            <img
                              src="images/Tiktok.png"
                              alt="FB Icon"
                              width="30"
                              height="30"
                              className="d-inline-block align-text-top"
                            />
                          </Link>
                        )}
                        {content.instaLinks && (
                          <Link
                            href={
                              content.instaLinks != null
                                ? content.instaLinks
                                : "/"
                            }
                            className={`${styles.badge} badge-success`}
                          >
                            <img
                              src="images/Ig.png"
                              alt="FB Icon"
                              width="30"
                              height="30"
                              className="d-inline-block align-text-top"
                            />
                          </Link>
                        )}
                      </div>
                    </div>

                    <br />
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
export default ProductView;
