"use client";
import AdminNavLoggedIn from "./NavbarAdminLoggedIn";
import CustomerNavbarLoggedIn from "./NavbarCustomerLoggedIn";
import NavbarNotLoggedIn from "./NavbarNotLoggedIn";

// react things
import React, { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import axios from "axios";

const AuthNavbar = () => {
  const { data: session } = useSession();
  const [accType, setAccType] = useState("");

  useEffect(() => {
    if (session) {
      axios.get(`/api/register/${session.user.email}`).then((res) => {
        setAccType(res.data.user.uRole);
      });
    }
  }, [session]);

  if (!session) {
    return <NavbarNotLoggedIn />;
  }

  if (accType === "customer") {
    return <CustomerNavbarLoggedIn />;
  }

  if (accType === "admin") {
    return <AdminNavLoggedIn />;
  }
};

export default AuthNavbar;
