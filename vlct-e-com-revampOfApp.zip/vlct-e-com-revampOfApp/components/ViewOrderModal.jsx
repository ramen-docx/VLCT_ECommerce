//React things
import React from "react";
import { useState, useEffect } from "react";
import axios from "axios";
import { useForm } from "react-hook-form";
import { set } from "mongoose";

import styles from "@/styles/manageproducts.module.css";
import ManageOrdersItems from "./ManageOrdersItems";

function ViewOrderModal({ setOrders, productID, orderList }) {
  const { setValue } = useForm({
    defaultValues: {},
  });
  useEffect(() => {
    setValue("orderDate", orderList.orderDate);
    setValue("orderStatus", orderList.orderStatus);
    setValue("orderOwner", orderList.orderOwner);
    setValue("customerName", orderList.customerName);
    setValue("address", orderList.address);
    setValue("contactNum", orderList.contactNum);
    setValue("paymentMethod", orderList.paymentMethod);
    setValue("paymentReferenceNum", orderList.paymentReferenceNum);
    setValue("transReceipt", orderList.transReceipt);
  }, [orderList]);

  return (
    <div
      className="modal fade"
      id="viewOrderModal"
      tabindex="-1"
      aria-labelledby="viewOrderModalLabel"
      aria-hidden="true"
    >
      <div className="modal-dialog modal-lg">
        <div className="modal-content h6">
          <div className="modal-header">
            <h1 className="modal-title fs-5" id="viewOrderModalLabel">
              View Order
            </h1>
            <button
              type="button"
              className="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
            ></button>
          </div>
          <div className="modal-body text-start">
            <label for="orderID" className="form-label">
              Order Contents
            </label>

            <div
              className={`${styles.orderContents} mb-3 border border-black p-1`}
            >
              {orderList.items &&
                orderList.items.map((item, index) => (
                  <div
                    key={index}
                    className={`${styles.cartItems} container-flex p-3 mb-1 border border-black`}
                  >
                    <div className="col">
                      <div className="d-flex justify-content-between">
                        <div className="d-flex justify-content-start">
                          <img
                            src={item.prdImage}
                            alt=""
                            width="110"
                            height="110"
                            className="d-inline-block align-text-top p-1"
                          />
                          <div>
                            <p
                              className={`${styles.cartItemTitles} fs-5 m-0 text-start`}
                            >
                              {item.prdName}
                            </p>
                            <p className="m-0 text-start">
                              Size: {item.prdSize}
                            </p>
                            <p className="m-0 text-start">
                              Variant: {item.prdColor}
                            </p>
                          </div>
                        </div>
                        <div className="d-flex justify-content-end">
                          <div>
                            <p
                              className={`${styles.cartItemTitles} fs-5 m-0 text-end`}
                            >
                              ₱ {item.prdPrice}
                            </p>
                            <p className="m-0 text-end">Qty: {item.quantity}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
            </div>
            <form>
              <div className="mb-3">
                <label for="orderDate" className="form-label">
                  Order Date
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="orderDate"
                  aria-describedby="emailHelp"
                  value={orderList.orderDate}
                  required
                  readOnly
                />
              </div>
              <div className="mb-3">
                <label for="orderDate" className="form-label">
                  Order Status
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="orderStatus"
                  aria-describedby="emailHelp"
                  value={orderList.orderStatus}
                  required
                  readOnly
                />
              </div>
              <div className="mb-3">
                <label for="prodPrice" className="form-label">
                  Total Amount (Shipping Fee Included)
                </label>
                <div className="input-group">
                  <span className="input-group-text">₱</span>
                  <input
                    type="number"
                    className="form-control"
                    id="prodPrice"
                    value={orderList.totalPrice}
                    required
                    readOnly
                  />
                </div>
              </div>

              <div className="mb-3">
                <label for="customerName" className="form-label">
                  Customer Name
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="customerName"
                  value={orderList.customerName}
                  aria-describedby="emailHelp"
                  required
                  readOnly
                />
              </div>
              <div className="mb-3">
                <label for="customerAddress" className="form-label">
                  Address
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="customerAddress"
                  value={orderList.address}
                  aria-describedby="emailHelp"
                  required
                  readOnly
                />
              </div>
              <div className="mb-3">
                <label for="contactNumber" className="form-label">
                  Contact Number
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="contactNumber"
                  value={orderList.contactNum}
                  aria-describedby="emailHelp"
                  required
                  readOnly
                />
              </div>
              <div className="mb-3">
                <label for="paymentOption" className="form-label">
                  Payment Method
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="paymentOption"
                  value={orderList.paymentMethod}
                  aria-describedby="emailHelp"
                  required
                  readOnly
                />
              </div>
              <div className="mb-3">
                <label for="paymentReferenceNumber" className="form-label">
                  Payment Reference Number
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="paymentReferenceNumber"
                  value={orderList.paymentReferenceNum}
                  aria-describedby="emailHelp"
                  required
                  readOnly
                />
              </div>

              <label for="paymentReceiptImage" className="form-label">
                Payment Receipt Image
              </label>

              <div className="mb-3 text-center border border-dark p-1">
                <img
                  alt=""
                  src={orderList.transReceipt}
                  width={400}
                  height={400}
                  className="img-fluid"
                />
              </div>

              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  data-bs-dismiss="modal"
                >
                  Close
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ViewOrderModal;
