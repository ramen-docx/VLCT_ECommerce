"use client";
import React from "react";
import OrderList from "@/components/OrderList";
import { useState } from "react";
import styles from "@/styles/manageproducts.module.css";

function ManageOrders() {
  const [showFulfilled, setShowFulfilled] = useState(false); // State to toggle between showing fulfilled and non-fulfilled orders

  const toggleShowFulfilled = () => {
    setShowFulfilled(!showFulfilled);
  };
  return (
    <>
      <div className="bg-light ">
        <div className="container-fluid bg-light border-top mt-1 p-2">
          <h1 className="text-center fw-bold">Manage Orders</h1>

          <div className="row border-top border pt-2 px-2 bg-white mx-1">
            <div className="col-6 text-start">
              <h3>Order List</h3>
            </div>
            <div className="col-6 text-end">
              <button
                onClick={toggleShowFulfilled}
                className={`${styles.addBtnSize} btn btn-primary mx-2 mb-2`}
              >
                {showFulfilled
                  ? "Show Non-Fulfilled Orders"
                  : "Show Fulfilled Orders"}
              </button>
            </div>
          </div>
        </div>

        <div className={`${styles.tableContent} container-fluid`}>
          <table
            className={`${styles.tableSize} table table-bordered table-white text-center`}
          >
            <thead className="sticky-top">
              <tr>
                <th scope="col">Order Date</th>
                <th scope="col">Customer Email</th>
                <th scope="col">Customer Name</th>
                <th scope="col">Address</th>
                <th scope="col">Total Amount</th>
                <th scope="col">Payment Method</th>
                <th scope="col">Transaction Receipt</th>
                <th scope="col">Status</th>
                <th scope="col">Actions</th>
              </tr>
            </thead>
            <tbody>
              <OrderList showFulfilled={showFulfilled} />
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

export default ManageOrders;
