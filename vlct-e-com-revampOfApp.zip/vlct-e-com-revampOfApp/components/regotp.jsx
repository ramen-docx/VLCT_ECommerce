"use client";
import styles from "@/styles/register.module.css";
import { Modal, Button, Form } from "react-bootstrap";
import { useState, useEffect } from "react";
import axios from "axios";
import { useRouter } from "next/navigation";

function RegistrationOTP({
  showModal,
  setShowModal,
  otp,
  registrationData,
  setError,
}) {
  const router = useRouter();

  const [currentOtp, setCurrentOtp] = useState(otp);
  const [userInputtedOtp, setUserInputtedOtp] = useState("");

  useEffect(() => {
    setCurrentOtp(otp);
  }, [otp]);

  const handleOtpChange = (e) => {
    const value = e.target.value;
    if (/^\d*$/.test(value) && value.length <= 4) {
      setUserInputtedOtp(value);
    }
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (userInputtedOtp == currentOtp) {
      submitToServer(registrationData);
    }
  };

  const submitToServer = (data) => {
    axios
      .post("/api/register", data)
      .then((res) => {
        router.push("/");
        console.log("triggerss");
      })
      .catch((err) => {
        setError(err.response.data.message);
      });
  };

  return (
    <>
      <Modal show={showModal} onHide={handleCloseModal}>
        <Modal.Header closeButton>
          <Modal.Title>OTP Verification</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="fs-4 mb-3 text-center">Enter OTP Code</div>
          <Form onSubmit={handleSubmit}>
            <div className="d-flex justify-content-center">
              <div className="form-floating mb-3 mx-1 col-4">
                <Form.Control
                  type="text"
                  id="userInputtedOtp"
                  name="userInputtedOtp"
                  inputMode="numeric"
                  required
                  maxLength={4}
                  placeholder="Enter OTP"
                  value={userInputtedOtp}
                  onChange={handleOtpChange}
                  className="text-center fs-1 p-1"
                />
              </div>
            </div>
            <div className="p text-center">
              We have sent you an OTP to your email.
            </div>
            <br />
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseModal}>
            Close
          </Button>
          <Button variant="primary" type="submit" onClick={handleSubmit}>
            Verify Account
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default RegistrationOTP;
