"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import styles from "@/styles/navbar.module.css";

function NavbarNotLoggedIn() {
  const [isOffcanvasOpen, setIsOffcanvasOpen] = useState(false);

  // Close offcanvas menu when clicked outside of it
  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (isOffcanvasOpen && !event.target.closest("#offcanvasNavbar")) {
        setIsOffcanvasOpen(false);
      }
    };

    document.body.addEventListener("click", handleOutsideClick);

    return () => {
      document.body.removeEventListener("click", handleOutsideClick);
    };
  }, [isOffcanvasOpen]);

  const toggleOffcanvas = () => {
    setIsOffcanvasOpen(!isOffcanvasOpen);
  };

  return (
    <div>
      <nav
        className={`${styles.navAdjust} navbar navbar-light bg-white fixed-top`}
      >
        <div className="container-fluid">
          <div className="navbar-header">
            <button
              className="navbar-toggler me-auto"
              type="button"
              onClick={toggleOffcanvas}
            >
              <span className="navbar-toggler-icon"></span>
            </button>
            <span className="navbar-brand mx-2">
              <Link href="/" className="navbar-brand">
                <img
                  src="images/navlogo.png"
                  alt=""
                  width="115"
                  height="35"
                  className={`${styles.navLogo} d-inline-block`}
                />
              </Link>
            </span>
          </div>
          <div
            className={`offcanvas offcanvas-start${
              isOffcanvasOpen ? " show" : ""
            }`}
            tabIndex="-1"
            id="offcanvasNavbar"
            aria-labelledby="offcanvasNavbarLabel"
            style={{ position: "fixed", top: 0, left: 0, zIndex: 1050 }}
          >
            <div className="offcanvas-header">
              <div className="d-flex flex-row mb-2">
                <div className="p-1 me-2 mt-1">
                  <button
                    type="button"
                    className="btn-close text-reset"
                    data-bs-dismiss="offcanvas"
                    aria-label="Close"
                    onClick={() => setIsOffcanvasOpen(false)}
                  ></button>
                </div>
                <div className="p-1">
                  <h5 className="offcanvas-title" id="offcanvasNavbarLabel">
                    VLCT Co. Apparel
                  </h5>
                </div>
              </div>
            </div>
            <div className="offcanvas-body">
              <ul className="navbar-nav justify-content-start flex-grow-1 pe-3">
                <li className="nav-item" onClick={toggleOffcanvas}>
                  <Link href="/" className="nav-link">
                    HOME
                  </Link>
                </li>
                <li className="nav-item" onClick={toggleOffcanvas}>
                  <Link href="/login" className="nav-link">
                    LOGIN
                  </Link>
                </li>
                <li className="nav-item" onClick={toggleOffcanvas}>
                  <Link href="/faqs" className="nav-link">
                    FREQUENTLY ASKED QUESTIONS
                  </Link>
                </li>
                <li className="nav-item" onClick={toggleOffcanvas}>
                  <Link href="/about" className="nav-link">
                    ABOUT
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="d-flex justify-content-end">
            <div className="pt-2 bd-highlight">
              <div className={styles.navLinkEffect}>
                <Link href="/login" className="nav-link">
                  <button type="button" className="btn btn-outline-dark">
                    Login
                  </button>
                </Link>
              </div>
            </div>
            <div className="p-2 bd-highlight">
              <div className={styles.navLinkEffect}>
                <Link href="/register" className="nav-link">
                  <button type="button" className="btn btn-dark">
                    Sign Up
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </nav>
    </div>
  );
}

export default NavbarNotLoggedIn;
