"use client";
// react imports
import React from "react";
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useRouter } from "next/navigation";
import { signOut, useSession } from "next-auth/react";
import axios from "axios";
import Link from "next/link";
import { set } from "mongoose";

function ConfirmSaveModal({
  loggedEmail,
  updatedUserData,
  profileImg,
  setError,
  setEditingMode,
}) {
  const router = useRouter();
  return (
    <div
      className="modal fade"
      id="confirmSaveModal"
      tabindex="-1"
      aria-labelledby="confirmSaveModalLabel"
      aria-hidden="true"
    >
      <div className="modal-dialog modal-dialog-centered text-start">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title" id="confirmSaveModalLabel">
              Save Changes
            </h5>
            <button
              type="button"
              className="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
            ></button>
          </div>
          <div className="modal-body">
            Are you sure you want to save these changes?
          </div>
          <div className="modal-footer">
            <button
              type="button"
              className="btn btn-secondary"
              data-bs-dismiss="modal"
            >
              Close
            </button>
            <button
              type="button"
              className="btn btn-primary"
              data-bs-dismiss="modal"
              onClick={() => {
                console.log("UserInput: ", loggedEmail, updatedUserData);
                axios
                  .patch(`/api/register/${loggedEmail}`, updatedUserData)
                  .then(() => {
                    setError("");
                    setEditingMode(false);
                  })
                  .catch((error) => {
                    if (error.response) {
                      setError(error.response.data.message);
                    } else {
                      console.error("Error during registration:", error);
                    }
                  });
              }}
            >
              Confirm
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ConfirmSaveModal;
