// ProductCard.js

import React, { useEffect, useState } from "react";
import styles from "@/styles/productcards.module.css";
import axios from "axios";
import ProductView from "./ProductView";
import { useForm } from "react-hook-form";

const ProductCard = ({ products, setProducts }) => {
  const [yeetedID, setYeetedID] = useState();
  const [yeetedProducts, setYeetedProducts] = useState([]);

  const {
    register,
    handleSubmit,
    watch,
    reset,
    formState: { errors },
  } = useForm();

  useEffect(() => {
    axios.get("/api/product").then((response) => {});
  }, [products]);

  function useSetYeetedShiz(ID, products) {
    setYeetedID(ID);
    setYeetedProducts(products);
  }

  return (
    <>
      {products.map((content) => (
        <div
          className={`${styles.card} shadow p-3`}
          key={content._id}
          data-bs-toggle="modal"
          data-bs-target="#ProductsView"
          onClick={() => {
            useSetYeetedShiz(content._id, content);
          }}
        >
          <div className={styles.imageContainer}>
            <img
              src={content.prdImage}
              alt="Product Image"
              className={styles.cardImage}
              width="300"
              height="300"
            />
          </div>

          <div className={styles.productTitle}>{content.prdName}</div>
          <div className={styles.productPrice}>₱ {content.prdPrice}</div>
        </div>
      ))}

      <ProductView
        setProducts={setProducts}
        productID={yeetedID}
        content={yeetedProducts}
      />
    </>
  );
};

export default ProductCard;
