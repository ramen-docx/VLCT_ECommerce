"use client";
import styles from "@/styles/manageproducts.module.css";
import UploadButton from "@/components/UploadButton";
import ImageUploadPreview from "@/components/ImageUploadPreview";

// react imports
import React from "react";
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useRouter } from "next/navigation";
import { signOut, useSession } from "next-auth/react";
import axios from "axios";
import Link from "next/link";
import { set } from "mongoose";

function AddProductsForm({ setProducts, setError }) {
  const [imageUrl, setImageUrl] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [AvailabilityFields, setAvailabilityFields] = useState([]);

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    reset,
    formState: { errors },
  } = useForm();

  useEffect(() => {
    setSelectedCategory(watch("prdCategory"));
  }, [watch("prdCategory")]);

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onload = function (e) {
      setUploadedFile(e.target.result);
    };

    reader.readAsDataURL(file);
  };

  function handleUploadSuccess(result) {
    setImageUrl(result.info.secure_url);
  }
  const handleDismiss = () => {
    setAvailabilityFields([]);
    reset();
    setImageUrl("");
  };

  const handleAddAvailabilityField = () => {
    const id = AvailabilityFields.length + 1;
    setAvailabilityFields([
      ...AvailabilityFields,
      { id: id, color: "", sizes: { S: 0, M: 0, L: 0, XL: 0 } },
    ]);
  };

  const handleRemoveAvailabilityField = (id) => {
    // Remove the field with the specified id
    const userInputAvailabilityFields = AvailabilityFields.map(
      (field, index) => ({
        id: index + 1,
        color: watch(`prdColor${index}`),
        size: {
          S: parseInt(watch(`prdSizeS${index}`)) || 0,
          M: parseInt(watch(`prdSizeM${index}`)) || 0,
          L: parseInt(watch(`prdSizeL${index}`)) || 0,
          XL: parseInt(watch(`prdSizeXL${index}`)) || 0,
        },
      })
    );
    const updatedAvailabilityFields = userInputAvailabilityFields.filter(
      (field) => field.id !== id + 1
    );
    // Reset the id of each field to its index in the array
    const resetIdFields = updatedAvailabilityFields.map((field, index) => ({
      ...field,
      id: index + 1,
    }));
    userInputAvailabilityFields.map((field, index) => {
      setValue(`prdColor${index}`, "");
      if (field.size) {
        const sizesEntries = Object.entries(field.size);
        sizesEntries.forEach(([size, quantity]) => {
          setValue(`prdSize${size}${index}`, "");
        });
      }
    });
    console.log("userInputAvailabilityFields", userInputAvailabilityFields);
    console.log("updatedAvailabilityFields", updatedAvailabilityFields);
    console.log("resetIdFields", resetIdFields);

    setAvailabilityFields((prevFields) => {
      return resetIdFields.map((field, index) => {
        setValue(`prdColor${index}`, field.color);
        let sizes = {};
        if (field.size) {
          const sizesEntries = Object.entries(field.size);
          sizesEntries.forEach(([size, quantity]) => {
            setValue(`prdSize${size}${index}`, quantity);
            sizes[size] = quantity;
          });
        }
        return {
          id: index,
          color: field.color,
          sizes: sizes,
        };
      });
    });
  };

  const onSubmit = (data) => {
    //=============================================================== checker for negative values ===============================================================
    //Check if Price and sizes are negative
    console.log("price====================", data.prdPrice);
    if (parseInt(data.prdPrice) < 0) {
      setError("Price cannot be negative");
      return false;
    }
    // checks if sizes are negative
    const isThereNegativeSizes = AvailabilityFields.map((field, index) => {
      const sizes = ["S", "M", "L", "XL"];
      const isNegative = sizes.some(
        (size) => watch(`prdSize${size}${index}`) < 0
      );
      console.log("isNegative", isNegative);
      if (isNegative) {
        setError("Stocks cannot be negative");
        return true;
      }
    }).includes(true);
    console.log("isThereNegativeSizes", isThereNegativeSizes);
    if (isThereNegativeSizes) {
      return false;
    }
    //=============================================================== end of checker for negative values ===============================================================

    const availabilityFields = AvailabilityFields.map((field, index) => ({
      id: index,
      color: data[`prdColor${index}`],
      sizes: {
        S: parseInt(data[`prdSizeS${index}`]) || 0,
        M: parseInt(data[`prdSizeM${index}`]) || 0,
        L: parseInt(data[`prdSizeL${index}`]) || 0,
        XL: parseInt(data[`prdSizeXL${index}`]) || 0,
      },
    }));

    const dataWithImg = {
      ...data,
      prdImage: imageUrl,
      prdAvailability: availabilityFields,
    };
    axios
      .post("/api/product", dataWithImg)
      .then((res) => {
        console.log(res);
        setProducts((previousProducts) => [
          ...previousProducts,
          res.data.newProducts,
        ]);

        reset();
        setImageUrl("");
        setError("");
        console.log(res.data.newProducts);
      })
      .catch((error) => {
        if (error.response) {
          setError(error.response.data.message);
        } else {
          console.error("Error during registration:", error);
        }
      });
  };

  const isFormValid = () => {
    const formData = {
      prdName: watch("prdName"),
      prdPrice: watch("prdPrice"),
      prdImage: imageUrl,

      // add checker for avail fields
    };
    // Check if any field is empty
    for (const key in formData) {
      if (!formData[key]) {
        return false;
      }
    }

    const isAnyFieldUndefined = AvailabilityFields.some((field, index) => {
      const colorField = watch(`prdColor${index}`);
      return colorField === undefined || colorField === "";
    });

    if (isAnyFieldUndefined) {
      return false;
    } else {
      return true;
    }

    return true;
  };
  return (
    <div
      className="modal fade"
      id="addModal"
      tabIndex="-1"
      aria-labelledby="addModalLabel"
      aria-hidden="true"
    >
      <div className="modal-dialog">
        <div className="modal-content h6">
          <div className="modal-header">
            <h1 className="modal-title fs-5 fw-bold" id="addModalLabel">
              Add Product
            </h1>
            <button
              type="button"
              className="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
              onClick={handleDismiss}
            ></button>
          </div>
          <div className="modal-body text-start">
            {/* =================================================== forms =================================================== */}
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="mb-3">
                <label htmlFor="prodName" className="form-label">
                  Product Name
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="prodName"
                  aria-describedby="emailHelp"
                  {...register("prdName")}
                />
                <label htmlFor="category" className="form-label">
                  Category:
                </label>
                <select
                  className={`${styles.selectBox} form-select`}
                  aria-label="Category Select"
                  {...register("prdCategory")}
                >
                  <option value="Apparel">Apparel</option>
                  <option value="Personal Care">Personal Care</option>
                  <option value="Others">Others</option>
                </select>
              </div>
              <div className="mb-3"></div>
              <div className="mb-3">
                <label htmlFor="prodPrice" className="form-label">
                  Price
                </label>
                <input
                  type="number"
                  className="form-control"
                  id="prodPrice"
                  {...register("prdPrice")}
                />
              </div>
              <div className="mb-3">
                <label htmlFor="prodDescription" className="form-label">
                  Description
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="prodDescription"
                  aria-describedby="emailHelp"
                  {...register("prdDescription")}
                />
              </div>

              <div className="mb-3">
                <label htmlFor="prodColor" className="form-label">
                  Available Variants
                </label>
                <button
                  type="button"
                  onClick={handleAddAvailabilityField}
                  className="btn btn-secondary mx-2 my-2"
                >
                  Add Variant
                </button>
                <hr></hr>
              </div>
              {selectedCategory === "Apparel" && (
                <>
                  {AvailabilityFields.map((AvailabilityField, index) => (
                    <div key={index}>
                      <div className="mb-3">
                        <label
                          htmlFor={`prodColor${index}`}
                          className="form-label"
                        >
                          Variant {index + 1}
                        </label>
                        <button
                          type="button"
                          onClick={() => handleRemoveAvailabilityField(index)}
                          className="btn btn-secondary mx-2 my-2"
                        >
                          Remove
                        </button>
                        <input
                          type="text"
                          className="form-control"
                          id={`prodColor${index}`}
                          aria-describedby="emailHelp"
                          onKeyDown={(e) => {
                            const isNumberKey = e.key >= "0" && e.key <= "9";
                            if (isNumberKey) {
                              e.preventDefault();
                            }
                          }}
                          {...register(`prdColor${index}`)}
                        />
                      </div>
                      <div className="mb-3">
                        <label htmlFor="prdSizes" className="form-label">
                          Sizes for {watch(`prdColor${index}`) || ""}
                        </label>

                        <div className="input-group flex-nowrap mb-3">
                          <span
                            className="input-group-text"
                            id="addon-wrapping"
                          >
                            S
                          </span>
                          <input
                            type="number"
                            className="form-control"
                            placeholder="0"
                            aria-label="small"
                            aria-describedby="addon-wrapping"
                            {...register(`prdSizeS${index}`)}
                          />
                          <span
                            className="input-group-text"
                            id="addon-wrapping"
                          >
                            M
                          </span>
                          <input
                            type="number"
                            className="form-control"
                            placeholder="0"
                            aria-label="medium"
                            aria-describedby="addon-wrapping"
                            {...register(`prdSizeM${index}`)}
                          />
                          <span
                            className="input-group-text"
                            id="addon-wrapping"
                          >
                            L
                          </span>
                          <input
                            type="number"
                            className="form-control"
                            placeholder="0"
                            aria-label="large"
                            aria-describedby="addon-wrapping"
                            {...register(`prdSizeL${index}`)}
                          />
                          <span
                            className="input-group-text"
                            id="addon-wrapping"
                          >
                            XL
                          </span>
                          <input
                            type="number"
                            className="form-control"
                            placeholder="0"
                            aria-label="extralarge"
                            aria-describedby="addon-wrapping"
                            {...register(`prdSizeXL${index}`)}
                          />
                        </div>

                        <hr />
                      </div>
                    </div>
                  ))}
                </>
              )}
              {selectedCategory !== "Apparel" && (
                <>
                  {AvailabilityFields.map((AvailabilityField, index) => (
                    <div key={index}>
                      <div className="mb-3">
                        <label
                          htmlFor={`prodColor${index}`}
                          className="form-label"
                        >
                          Variant {index + 1}
                        </label>
                        <button
                          type="button"
                          onClick={() => handleRemoveAvailabilityField(index)}
                          className="btn btn-secondary mx-2 my-2"
                        >
                          Remove
                        </button>
                        <input
                          type="text"
                          className="form-control"
                          id={`prodColor${index}`}
                          aria-describedby="emailHelp"
                          onKeyDown={(e) => {
                            const isNumberKey = e.key >= "0" && e.key <= "9";
                            if (isNumberKey) {
                              e.preventDefault();
                            }
                          }}
                          {...register(`prdColor${index}`)}
                        />
                      </div>
                      <div className="mb-3">
                        <label htmlFor="prdSizes" className="form-label">
                          Stocks for {watch(`prdColor${index}`) || ""}
                        </label>

                        <div className="input-group flex-nowrap mb-3">
                          <span
                            className="input-group-text"
                            id="addon-wrapping"
                          >
                            Stock
                          </span>
                          <input
                            type="number"
                            className="form-control"
                            placeholder="0"
                            aria-label="small"
                            aria-describedby="addon-wrapping"
                            {...register(`prdSizeS${index}`)}
                          />
                        </div>
                        <hr />
                      </div>
                    </div>
                  ))}
                </>
              )}

              <div className="mb-3">
                <h5>Links</h5>
                <hr></hr>
                <label htmlFor="linkFacebook" className="-label">
                  Facebook
                </label>
                <input
                  type="text"
                  className="form-control mb-3"
                  id="linkFacebook"
                  aria-describedby="emailHelp"
                  {...register("fbLink")}
                />

                <label htmlFor="linkTiktok" className="form-label">
                  Tiktok
                </label>
                <input
                  type="text"
                  className="form-control mb-3"
                  id="linkTiktok"
                  aria-describedby="emailHelp"
                  {...register("tiktokLink")}
                />

                <label htmlFor="linkInstagram" className="form-label">
                  Instagram
                </label>
                <input
                  type="text"
                  className="form-control mb-3"
                  id="linkInstagram"
                  aria-describedby="emailHelp"
                  {...register("instaLinks")}
                />

                <hr></hr>
              </div>

              {/* IMAGE BUTTON */}
              <div className="mb-3">
                <UploadButton onUpload={handleUploadSuccess} />
              </div>

              <div className="mb-3 text-center border border-dark p-1">
                {!imageUrl ? (
                  <img
                    src="images/placeholder.png"
                    width={150}
                    height={150}
                    alt="placeholder.png"
                  />
                ) : (
                  <ImageUploadPreview
                    imageUrl={imageUrl}
                    width={150}
                    height={150}
                  />
                )}
              </div>

              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  data-bs-dismiss="modal"
                  onClick={() => handleDismiss}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn btn-primary"
                  data-bs-dismiss="modal"
                  disabled={!isFormValid()}
                >
                  Add Product
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AddProductsForm;
