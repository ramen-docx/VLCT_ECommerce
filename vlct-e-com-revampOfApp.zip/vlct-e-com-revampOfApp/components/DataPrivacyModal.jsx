import React, { useState } from "react";
import Link from "next/link";

function DataPrivacyModal({ onAccept }) {
  const [accepted, setAccepted] = useState(false);

  const handleAccept = () => {
    setAccepted(true);
    onAccept();
  };

  return (
    <>
      <div
        className="modal fade"
        id="dataPrivModal"
        tabIndex="-1"
        aria-labelledby="dataPrivModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-lg modal-dialog-scrollable">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">Terms and Conditions</h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div className="modal-body">
              <br></br>
              <h5>Clause 1: Order Placement:</h5>
              <p>
                By placing an order on the VLCT Co. e-commerce website, you
                agree to be bound by these Terms and Conditions.
              </p>
              <br></br>
              <br></br>
              <h5>Clause 2: Product Availability:</h5>
              <p>
                All orders are subject to product availability. We reserve the
                right to cancel any order if the product is no longer available.
                In such cases, we will notify you and provide a refund or offer
                a suitable replacement.
              </p>
              <br></br>
              <br></br>
              <h5>Clause 3: Pricing and Payment:</h5>{" "}
              <p>
                Prices for products are listed in Philippine Peso (PHP) and are
                subject to change without notice. Payment must be made in full
                at the time of placing the order. We accept payment via Gcash,
                BDO or GoTyme Bank.
              </p>
              <br></br>
              <br></br>
              <h5>Clause 4: Shipping and Delivery:</h5>
              <p>
                We strive to ship orders promptly; however, delivery times may
                vary depending on your location and shipping method selected. We
                are not responsible for any delays or damages during shipping.
                Additional shipping charges may apply.
              </p>
              <br></br>
              <br></br>
              <h5>Clause 5: Return and Refund Policy:</h5>{" "}
              <p>
                We offer a 3 days return policy for eligible products. To
                initiate a return, please contact VLCT Business Messenger, our
                customer service representative, within the specified timeframe.
                Refunds will be issued to the original form of payment upon
                receipt and inspection of the returned items.
              </p>
              <br></br>
              <br></br>
              <h5>Clause 6: Governing Law:</h5>{" "}
              <p>
                These Terms and Conditions shall be governed by and construed in
                accordance with the laws of the Philippines, without regard to
                its conflict of law provisions.
              </p>
              <br></br>
              <br></br>
              <h5>Clause 7: Changes to Terms:</h5>{" "}
              <p>
                VLCT Co. reserves the right, at its sole discretion, to modify
                or replace these Terms and Conditions at any time. It is your
                responsibility to review these Terms and Conditions periodically
                for changes.
              </p>
              <br></br>
              <br></br>
              <p>
                By placing an order on VLCT Co. e-commerce website, you
                acknowledge that you have read, understood, and agree to be
                bound by these Terms and Conditions.
              </p>
              <br></br>
              <h4>Registration Agreement</h4>
              <br></br>
              <h5>Clause 1: Data Gathering:</h5> By creating an account on VLCT
              Co. e-commerce website, you acknowledge and agree that VLCT Co.
              collects and processes your personal data for legal and legitimate
              business purposes, including but not limited to processing your
              orders, providing customer support, and complying with legal
              obligations.
              <br></br>
              <br></br>
              <h5>Clause 2: Consent to Data Collection:</h5> By registering for
              an account, you consent to the collection, storage, and processing
              of your personal data by VLCT Co. in accordance with our Privacy
              Policy.
              <br></br>
              <br></br>
              <h5>Clause 3: Types of Data Collected:</h5> The types of personal
              data we may collect include your name, email address, shipping
              address, payment information, and other information provided
              during the registration process or through your interactions with
              our website.
              <br></br>
              <br></br>
              <h5>Clause 4: Use of Data:</h5> We may use your personal data to
              communicate with you, process your orders, improve our products
              and services, prevent fraud, and comply with legal obligations.
              <br></br>
              <br></br>
              <h5>Clause 5: Third-Party Service Providers:</h5> We may share
              your personal data with third-party service providers who assist
              us in operating our website, conducting our business, or servicing
              you, as long as those parties agree to keep this information
              confidential.
              <br></br>
              <br></br>
              <h5>Clause 6: Data Retention:</h5> We will retain your personal
              data for as long as necessary to fulfill the purposes outlined in
              this Agreement, unless a longer retention period is required or
              permitted by law.
              <br></br>
              <br></br>
              <h5>Clause 7: Your Rights:</h5> You have the right to access,
              update, or delete your personal data, as well as to object to or
              restrict its processing. For more information on exercising your
              rights, please refer to our Privacy Policy.
              <br></br>
              <br></br>
              <h5>Clause 8: Security Measures:</h5> We implement appropriate
              technical and organizational measures to protect your personal
              data against unauthorized access, alteration, disclosure, or
              destruction.
              <br></br>
              <br></br>
              <h5>Clause 9: Legal Basis:</h5> The legal basis for processing
              your personal data is your consent, the necessity of processing
              for the performance of a contract with you, compliance with legal
              obligations, or our legitimate interests.
              <br></br>
              <br></br>
              <h5>Clause 10: Changes to Agreement:</h5> VLCT Co. reserves the
              right to modify or update this Registration Agreement at any time.
              We will notify you of any changes by posting the new Agreement on
              this page.
              <br></br>
              <br></br>
              By creating an account on VLCT Co. e-commerce website, you
              acknowledge that you have read, understood, and agree to the terms
              outlined in this Registration Agreement, including the collection
              and processing of your personal data for legal reasons.
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default DataPrivacyModal;
