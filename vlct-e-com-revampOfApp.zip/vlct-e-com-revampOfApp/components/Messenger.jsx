"use client";
import React, { useState, useEffect } from "react";

function Messenger() {
  const url = "https://www.messenger.com/t/112533793758126";
  const [isHovered, setIsHovered] = useState(false);
  const [isPhoneMode, setIsPhoneMode] = useState(false);

  const handleClick = () => {
    window.open(url, "_blank");
  };

  useEffect(() => {
    const handleResize = () => {
      setIsPhoneMode(window.innerWidth <= 600);
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  const buttonStyle = {
    position: "fixed",
    bottom: isPhoneMode ? "20px" : "2%",
    right: isPhoneMode ? "20px" : "2%",
    width: "60px",
    height: "60px",
    borderRadius: "50%",
    padding: "10px",
    backgroundImage:
      "url('https://helios-i.mashable.com/imagery/articles/046V6VhIsS7y5kAQzUbRY2m/hero-image.fill.size_1248x702.v1623390961.jpg')", // Replace with your image URL
    backgroundPosition: "center",
    backgroundSize: "cover",
    backgroundRepeat: "no-repeat",
    border: "none",
    zIndex: "999", // Ensure button appears on top of other elements
    cursor: "pointer", // Show pointer cursor on hover
    boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)", // Add shadow for depth
    transition: "all 0.3s ease", // Smooth transition for hover effect
    transform: isHovered ? "scale(1.1)" : "scale(1)", // Increase size on hover
  };

  return (
    <button
      style={buttonStyle}
      onClick={handleClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    ></button>
  );
}

export default Messenger;
