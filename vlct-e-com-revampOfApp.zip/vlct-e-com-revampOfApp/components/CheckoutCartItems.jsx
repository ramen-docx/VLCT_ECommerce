import styles from "../styles/checkout.module.css";

function CheckoutCartItems() {
  return (
    <div
      className={`${styles.cartItems} container-flex p-3 mb-1 border border-black`}
    >
      <div className="col">
        <div className="d-flex justify-content-between">
          <div className="d-flex justify-content-start">
            <img
              src="images/placeholder.png"
              alt=""
              width="110"
              height="110"
              className="d-inline-block align-text-top p-1"
            />
            <div>
              <p className={`${styles.cartItemTitles} fs-5 m-0 text-start`}>
                Product 1
              </p>
              <p cla ssName="m-0 text-start">
                Size: M
              </p>
              <p className="m-0 text-start">Variant: Black</p>
            </div>
          </div>
          <div className="d-flex justify-content-end">
            <div>
              <p className={`${styles.cartItemTitles} fs-5 m-0 text-end`}>
                PHP 150
              </p>
              <p className="m-0 text-end">Qty: 1</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CheckoutCartItems;
