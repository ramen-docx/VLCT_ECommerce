"use client";
import Messenger from "@/components/Messenger";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import styles from "@/styles/navbar.module.css";
import { signOut } from "next-auth/react";
import { useSession } from "next-auth/react";
import axios from "axios";

function CustomerNavLoggedIn() {
  const [isOffcanvasOpen, setIsOffcanvasOpen] = useState(false);
  const { data: session } = useSession();
  const [profilePic, setProfilePic] = useState();
  const [email, setEmail] = useState(session?.user?.email);

  useEffect(() => {
    if (email) {
      axios
        .get(`/api/register/${email}`)
        .then((res) => {
          setProfilePic(res.data.user.uImg);
        })
        .catch((error) => {
          console.log("Error fetching user data:", error);
        });
    }
  }, [email]);

  // Close offcanvas menu when clicked outside of it
  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (isOffcanvasOpen && !event.target.closest("#offcanvasNavbar")) {
        setIsOffcanvasOpen(false);
      }
    };

    document.body.addEventListener("click", handleOutsideClick);

    return () => {
      document.body.removeEventListener("click", handleOutsideClick);
    };
  }, [isOffcanvasOpen]);

  const toggleOffcanvas = () => {
    setIsOffcanvasOpen(!isOffcanvasOpen);
  };

  return (
    <div>
      <Messenger />
      <nav
        className={`${styles.navAdjust} navbar navbar-light bg-white fixed-top`}
      >
        <div className="container-fluid">
          <div className="navbar-header">
            <button
              className="navbar-toggler me-auto"
              type="button"
              onClick={toggleOffcanvas}
            >
              <span className="navbar-toggler-icon"></span>
            </button>
            <span className="navbar-brand mx-2">
              <Link href="/" className="navbar-brand">
                <img
                  src="images/navlogo.png"
                  alt=""
                  width="115"
                  height="35"
                  className={`${styles.navLogo} d-inline-block`}
                />
              </Link>
            </span>
          </div>
          <div
            className={`offcanvas offcanvas-start${
              isOffcanvasOpen ? " show" : ""
            }`}
            tabIndex="-1"
            id="offcanvasNavbar"
            aria-labelledby="offcanvasNavbarLabel"
            style={{ position: "fixed", top: 0, left: 0, zIndex: 1050 }}
          >
            <div className="offcanvas-header">
              <div className="d-flex flex-row mb-2">
                <div className="p-1 me-2 mt-1">
                  <button
                    type="button"
                    className="btn-close text-reset"
                    data-bs-dismiss="offcanvas"
                    aria-label="Close"
                    onClick={() => setIsOffcanvasOpen(false)}
                  ></button>
                </div>
                <div className="p-1">
                  <h5 className="offcanvas-title" id="offcanvasNavbarLabel">
                    VLCT Co. Apparel
                  </h5>
                </div>
              </div>
            </div>
            <div className="offcanvas-body">
              <ul className="navbar-nav justify-content-start flex-grow-1 pe-3">
                <li className="nav-item" onClick={toggleOffcanvas}>
                  <Link href="/myorders" className="nav-link">
                    MY ORDERS
                  </Link>
                </li>
                <li className="nav-item" onClick={toggleOffcanvas}>
                  <Link href="/faqs" className="nav-link">
                    FREQUENTLY ASKED QUESTIONS
                  </Link>
                </li>
                <li className="nav-item" onClick={toggleOffcanvas}>
                  <Link href="/about" className="nav-link">
                    ABOUT
                  </Link>
                </li>
                <li className="nav-item" onClick={toggleOffcanvas}>
                  <Link
                    onClick={() => signOut()}
                    href="/login"
                    className="nav-link"
                  >
                    LOG OUT
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="d-flex justify-content-end">
            <div className="p-3 bd-highlight">
              <div className={styles.navLinkEffect}>
                <Link href="/" className="nav-link">
                  HOME
                </Link>
              </div>
            </div>
            <div className="p-2 bd-highlight position-relative">
              <div className={styles.navLinkEffect}>
                <div className="dropdown">
                  <a
                    href="#"
                    className="nav-link dropdown-toggle d-flex align-items-center"
                    role="button"
                    id="profileDropdown"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    {profilePic ? (
                      <img
                        src={profilePic}
                        alt="Profile"
                        width="40"
                        height="40"
                        className="d-inline-block align-text-top me-1 rounded-circle"
                      />
                    ) : (
                      <img
                        src="images/placeholder.png"
                        alt="Profile"
                        width="40"
                        height="40"
                        className="d-inline-block align-text-top me-1 rounded-circle"
                      />
                    )}
                    <span className="dropdown-toggle-arrow"></span>
                  </a>
                  <ul
                    className="dropdown-menu dropdown-menu-end"
                    aria-labelledby="profileDropdown"
                  >
                    <li className="dropdown-header">
                      Hello,{" "}
                      {session.user.name
                        ? session.user.name.length > 15
                          ? session.user.name.substring(0, 15) + "..."
                          : session.user.name
                        : "User"}
                    </li>

                    <li>
                      <Link href="/profile" className="dropdown-item">
                        Profile
                      </Link>
                    </li>
                    <li>
                      <button
                        onClick={() => signOut()}
                        className="dropdown-item"
                        type="button"
                      >
                        Log out
                      </button>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="p-2 bd-highlight">
              <div className={styles.navCartEffect}>
                <Link href="/cart" className="nav-link">
                  <img
                    src="images/shopping-cart.png"
                    alt=""
                    width="30"
                    height="30"
                    className="d-inline-block align-text-top ms-1"
                  />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </nav>
    </div>
  );
}

export default CustomerNavLoggedIn;
