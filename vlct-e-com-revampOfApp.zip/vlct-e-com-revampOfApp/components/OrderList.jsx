// react imports
import React from "react";
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useRouter } from "next/navigation";
import { signOut, useSession } from "next-auth/react";
import axios from "axios";

import styles from "@/styles/manageproducts.module.css";
import Link from "next/link";
import ViewOrder from "./ViewOrder";
import CancelOrderModal from "./CancelOrderModal";

function OrderList({ showFulfilled }) {
  const [orders, setOrders] = useState([]);
  const [yeetedID, setYeetedID] = useState();
  const [yeetedOrder, setYeetedOrder] = useState([]);
  const [deleteOrderID, setDeleteOrderID] = useState();

  const {
    register,
    handleSubmit,
    watch,
    reset,
    formState: { errors },
  } = useForm();

  useEffect(() => {
    axios.get("/api/order").then((response) => {
      setOrders(response.data);
    });
  }, []);

  function useSetYeetedShiz(ID, orderList) {
    setYeetedID(ID);
    setYeetedOrder(orderList);
  }

  const deleteOrder = (orderID) => {
    axios.delete(`/api/order/${orderID}`).then((response) => {
      setOrders((previousOrder) =>
        previousOrder.filter((orders) => orders._id !== orderID)
      );
    });
  };

  const filteredOrders = showFulfilled
    ? orders.filter((order) => order.orderStatus === "fulfilled")
    : orders.filter((order) => order.orderStatus !== "fulfilled");

  return (
    <>
      {filteredOrders.map((orderList) => (
        <tr>
          <th scope="row" className={styles.oneline} key={orderList._id}>
            {orderList.orderDate}
          </th>
          <td className={styles.oneline}>{orderList.orderOwner}</td>
          <td className={styles.oneline}>{orderList.customerName}</td>
          <td className={styles.oneline}>{orderList.address}</td>
          <td className={styles.oneline}>{orderList.totalPrice}</td>
          <td className={styles.oneline}>{orderList.paymentMethod}</td>
          <td>
            <img
              src={orderList.transReceipt}
              alt=""
              className={`${styles.imageSize} img-fluid d-inline-block align-text-top p-1`}
            />
          </td>
          <td className={styles.oneline}>{orderList.orderStatus}</td>
          <td>
            <button
              type="button"
              className={`${styles.btnSize} btn btn-primary mx-0 mx-md-2 p-0 p-md-1`}
              data-bs-toggle="modal"
              data-bs-target="#editModal"
              onClick={() => {
                useSetYeetedShiz(orderList._id, orderList);
              }}
            >
              View
            </button>

            <ViewOrder
              setOrders={setOrders}
              setYeetedID={yeetedID}
              orderList={yeetedOrder}
            />

            <button
              type="button"
              className={`${styles.btnSize} btn btn-danger mx-0 mx-md-2 p-0 p-md-1`}
              data-bs-toggle="modal"
              data-bs-target="#cancelOrderModal"
              onClick={() => {
                setDeleteOrderID(orderList._id);
              }}
            >
              Cancel
            </button>
            <CancelOrderModal onDelete={() => deleteOrder(deleteOrderID)} />
          </td>
        </tr>
      ))}
    </>
  );
}

export default OrderList;
