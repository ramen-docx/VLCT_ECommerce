// AaHomepage.js

import React, { useState, useEffect } from "react";
import styles from "@/app/page.module.css";
import ProductCard from "./ProductCards";
import axios from "axios";

function AaHomepage({ cardContainerRef }) {
  const [searchQuery, setSearchQuery] = useState("");
  const [products, setProducts] = useState([]);

  useEffect(() => {
    axios.get("/api/product").then((response) => {
      setProducts(response.data);
    });
  }, []);

  // Filter products based on searchQuery
  const filteredProducts = products.filter((product) =>
    product.prdName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <>
      <div className="fs-2 fw-bold text-center my-4" ref={cardContainerRef}>
        PRODUCTS
      </div>
      <div className="row justify-content-center">
        <form
          className={`${styles.searchWidth} d-flex mb-1`}
          role="search"
          onSubmit={(e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            setSearchQuery(formData.get("searchQuery"));
          }}
        >
          <input
            className="form-control me-2"
            type="search"
            placeholder="Search"
            aria-label="Search"
            name="searchQuery"
          />
          <button className="btn btn-outline-dark" type="submit">
            Search
          </button>
        </form>
      </div>
      <div className={styles.homeMargins}>
        <hr className="me-md-5 border border-black"></hr>
        <div className={styles.cardContainer}>
          <ProductCard products={filteredProducts} />
        </div>
      </div>
      <br />
    </>
  );
}

export default AaHomepage;
