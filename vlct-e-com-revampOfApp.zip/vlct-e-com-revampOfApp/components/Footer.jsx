import Link from "next/link";
import styles from "@/styles/navbar.module.css";
function Footer() {
  return (
    <>
      <div>
        <footer className={`${styles.footerAdjust} py-4 bg-white shadow-lg`}>
          <ul className="nav justify-content-center border-bottom pb-3 mb-3">
            <li className="nav-item">
              <Link href="/" className="nav-link px-2 text-dark">
                Home
              </Link>
            </li>
            <li className="nav-item">
              <Link href="/" className="nav-link px-2 text-dark">
                Products
              </Link>
            </li>
            <li className="nav-item">
              <Link href="/faqs" className="nav-link px-2 text-dark">
                FAQs
              </Link>
            </li>
            <li className="nav-item">
              <Link href="/about" className="nav-link px-2 text-dark">
                About
              </Link>
            </li>
          </ul>
          <p className="text-center text-muted">© 2024 VLCT Apparel Co.</p>
        </footer>
      </div>
    </>
  );
}

export default Footer;
