"use client";
import styles from "@/styles/profile.module.css";
import UploadButton from "@/components/UploadButton";
import ImageUploadPreview from "@/components/ImageUploadPreview";
//React things
import React from "react";
import { useState, useEffect } from "react";
import axios from "axios";
import { useForm } from "react-hook-form";
import { set } from "mongoose";

function EditProductsForm({
  setProducts,
  productID,
  content,
  setError,
  setYeetedProducts,
}) {
  const [imageUrl, setImageUrl] = useState(content.prdImage);
  const [selectedCategory, setSelectedCategory] = useState("Apparel");
  const [AvailabilityFields, setAvailabilityFields] = useState([""]);

  function setDatatoForm() {
    setValue("prdName", content.prdName);
    setValue("prdPrice", content.prdPrice);
    setValue("prdDescription", content.prdDescription);
    setValue("prdCategory", content.prdCategory);
    setValue("fbLink", content.fbLink);
    setValue("tiktokLink", content.tiktokLink);
    setValue("instaLinks", content.instaLinks);
    setImageUrl(content.prdImage);
  }
  function primerForAvailabilityFields() {
    if (content.prdAvailability) {
      setAvailabilityFields((prevFields) => {});
      setAvailabilityFields((prevFields) => {
        return content.prdAvailability.map((field, index) => {
          setValue(`prdColor${index}`, field.color);
          let sizes = {};
          if (field.sizes) {
            const sizesEntries = Object.entries(field.sizes);
            sizesEntries.forEach(([size, quantity]) => {
              setValue(`prdSize${size}${index}`, quantity);
              sizes[size] = quantity;
            });
          }
          return {
            id: field.id,
            color: field.color,
            sizes: sizes,
          };
        });
      });
    }
  }
  const {
    register,
    handleSubmit,
    watch,
    reset,
    setValue,
    formState: { errors },
  } = useForm({
    defaultValues: {
      prdPrice: content.prdPrice,
      prdDescription: content.prdDescription,
      fbLink: content.fbLink,
      tiktokLink: content.tiktokLink,
      instaLinks: content.instaLinks,
    },
  });
  useEffect(() => {
    setSelectedCategory(watch("prdCategory"));
  }, [watch("prdCategory")]);

  useEffect(() => {
    setDatatoForm();
    // sets the Availability Colors Fields
    primerForAvailabilityFields();
  }, [content]);

  // for displaying puposes and debugging ==============================
  /* prettier-ignore */

  function handleUploadSuccess(result) {
    setImageUrl(result.info.secure_url);
  }

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onload = function (e) {
      setUploadedFile(e.target.result);
    };

    reader.readAsDataURL(file);
  };

  const handleAddAvailabilityField = () => {
    const id = AvailabilityFields.length;
    setAvailabilityFields([
      ...AvailabilityFields,
      { id: id, value: "", sizes: { S: 0, M: 0, L: 0, XL: 0 } },
    ]);
  };
  const handleDismiss = () => {
    setDatatoForm();
    reset();
    primerForAvailabilityFields();
  };

  const handleRemoveAvailabilityField = (id) => {
    //removes color field
    const userInputAvailabilityFields = AvailabilityFields.map(
      (field, index) => ({
        id: index + 1,
        color: watch(`prdColor${index}`),
        size: {
          S: parseInt(watch(`prdSizeS${index}`)) || 0,
          M: parseInt(watch(`prdSizeM${index}`)) || 0,
          L: parseInt(watch(`prdSizeL${index}`)) || 0,
          XL: parseInt(watch(`prdSizeXL${index}`)) || 0,
        },
      })
    );

    const updatedAvailabilityFields = userInputAvailabilityFields.filter(
      (field) => field.id !== id + 1
    );
    const resetIdFields = updatedAvailabilityFields.map((field, index) => ({
      ...field,
      id: index + 1,
    }));

    userInputAvailabilityFields.map((field, index) => {
      setValue(`prdColor${index}`, "");
      if (field.size) {
        const sizesEntries = Object.entries(field.size);
        sizesEntries.forEach(([size, quantity]) => {
          setValue(`prdSize${size}${index}`, "");
        });
      }
    });
    setAvailabilityFields((prevFields) => {
      return resetIdFields.map((field, index) => {
        setValue(`prdColor${index}`, field.color);

        let sizes = {};
        if (field.size) {
          const sizesEntries = Object.entries(field.size);
          sizesEntries.forEach(([size, quantity]) => {
            setValue(`prdSize${size}${index}`, quantity);
            sizes[size] = quantity;
          });
        }
        return {
          id: index,
          color: field.color,
          sizes: sizes,
        };
      });
    });
  };

  const onSubmit = (data) => {
    //=============================================================== checker for negative values ===============================================================
    //Check if Price and sizes are negative
    console.log("price====================", data.prdPrice);
    if (parseInt(data.prdPrice) < 0) {
      setError("Price cannot be negative");
      return false;
    }
    // checks if sizes are negative

    const isThereNegativeSizes = AvailabilityFields.map((field, index) => {
      const sizes = ["S", "M", "L", "XL"];
      const isNegative = sizes.some(
        (size) => watch(`prdSize${size}${index}`) < 0
      );
      console.log("isNegative", isNegative);
      if (isNegative) {
        setError("Stocks cannot be negative");
        return true;
      }
    }).includes(true);
    console.log("isThereNegativeSizes", isThereNegativeSizes);
    if (isThereNegativeSizes) {
      return false;
    }

    const availabilityFields = AvailabilityFields.map((field, index) => ({
      id: index,
      color: data[`prdColor${field.id}`],
      sizes: {
        S: parseInt(data[`prdSizeS${field.id}`]) || 0,
        M: parseInt(data[`prdSizeM${field.id}`]) || 0,
        L: parseInt(data[`prdSizeL${field.id}`]) || 0,
        XL: parseInt(data[`prdSizeXL${field.id}`]) || 0,
      },
    }));

    const dataWithImg = {
      ...data,
      prdImage: imageUrl,
      prdAvailability: availabilityFields,
    };

    axios
      .patch(`/api/product/${productID}`, dataWithImg)
      .then((response) => {
        setProducts((previousProduct) =>
          previousProduct.map((products) =>
            products._id === productID ? response.data : products
          )
        );
        reset();
        setError("");
      })
      .catch((error) => {
        if (error.response) {
          setError(error.response.data.message);
          reset();
          setYeetedProducts(data);
        } else {
          console.error("Error during registration:", error);
        }
      });
  };

  const isFormValid = () => {
    const formData = {
      prdName: watch("prdName"),
      prdPrice: watch("prdPrice"),
      prdImage: imageUrl,

      // add checker for avail fields
    };
    // Check if any field is empty
    for (const key in formData) {
      if (!formData[key]) {
        return false;
      }
    }

    const isAnyFieldUndefined = AvailabilityFields.some((field, index) => {
      const colorField = watch(`prdColor${index}`);
      return colorField === undefined || colorField === "";
    });

    if (isAnyFieldUndefined) {
      return false;
    } else {
      return true;
    }

    return true;
  };

  return (
    <div
      className="modal fade"
      id={"editModal"}
      tabIndex="-1"
      aria-labelledby="editModalLabel"
      aria-hidden="true"
    >
      <div className="modal-dialog">
        <div className="modal-content h6">
          <div className="modal-header">
            <h1 className="modal-title fs-5 fw-bold" id="editModalLabel">
              Edit Product
            </h1>
            <button
              type="button"
              className="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
              onClick={handleDismiss}
            ></button>
          </div>
          <div className="modal-body text-start">
            <form onSubmit={handleSubmit(onSubmit)}>
              {/* <div className="form-check mb-3">
                <input
                  className="form-check-input"
                  type="checkbox"
                  id="prdHide"
                  name=""
                  checked={content.prdHide}
                  {...register("prdHide")}
                />
                <label className="form-check-label" htmlFor="prdHide">
                  Hide Product
                </label>
              </div> */}
              <div className="mb-3">
                <label htmlFor="prodName" className="form-label">
                  Product Name
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="prodName"
                  aria-describedby="emailHelp"
                  {...register("prdName")}
                />
              </div>
              <div className="mb-3">
                <label htmlFor="category" className="form-label">
                  Category:
                </label>
                <select
                  className={`${styles.selectBox1} form-select w-100`}
                  aria-label="Category Select"
                  {...register("prdCategory")}
                >
                  <option value="Apparel">Apparel</option>
                  <option value="Personal Care">Personal Care</option>
                  <option value="Others">Others</option>
                </select>
              </div>
              <div className="mb-3">
                <label htmlFor="prodPrice" className="form-label">
                  Price
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="prodPrice"
                  {...register("prdPrice")}
                />
              </div>
              <div className="mb-3">
                <label htmlFor="prodDescription" className="form-label">
                  Description
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="prodDescription"
                  aria-describedby="emailHelp"
                  {...register("prdDescription")}
                />
              </div>

              {selectedCategory === "Apparel" && (
                <>
                  <div className="mb-3">
                    <label htmlFor="prodColor" className="form-label">
                      Available Variants
                    </label>
                    <button
                      type="button"
                      onClick={handleAddAvailabilityField}
                      required={true}
                      className="btn btn-secondary mx-2 my-2"
                    >
                      Add Variant
                    </button>
                    <hr></hr>
                  </div>
                  {AvailabilityFields ? (
                    AvailabilityFields.map(
                      (field, index) =>
                        field && (
                          <div key={field.id}>
                            <div className="mb-3">
                              <label
                                htmlFor={`prodColor${field.id}`}
                                className="form-label"
                              >
                                Variant {field.id + 1}
                              </label>
                              <button
                                type="button"
                                onClick={() =>
                                  handleRemoveAvailabilityField(index)
                                }
                                className="btn btn-secondary mx-2 my-2"
                              >
                                Remove
                              </button>
                              <input
                                type="text"
                                className="form-control"
                                required={true}
                                id={`prodColor${field.id}`}
                                {...register(`prdColor${field.id}`)}
                              />
                            </div>
                            <div className="mb-3">
                              <label
                                htmlFor={`prdSizes${field.id}`}
                                className="form-label"
                              >
                                Sizes for {field.color}
                              </label>

                              <div className="input-group flex-nowrap mb-3">
                                {field.sizes &&
                                  Object.entries(field.sizes).map(
                                    ([size, value]) => (
                                      <div
                                        key={size}
                                        className="input-group flex-nowrap mb-3"
                                      >
                                        <span
                                          className="input-group-text"
                                          id="addon-wrapping"
                                        >
                                          {size}
                                        </span>
                                        <input
                                          type="number"
                                          className="form-control"
                                          placeholder="0"
                                          aria-label={size}
                                          aria-describedby="addon-wrapping"
                                          {...register(
                                            `prdSize${size}${field.id}`
                                          )}
                                        />
                                      </div>
                                    )
                                  )}
                              </div>
                            </div>
                            <hr />
                          </div>
                        )
                    )
                  ) : (
                    <p>No availability fields</p>
                  )}
                </>
              )}
              {selectedCategory !== "Apparel" && (
                <>
                  <div className="mb-3">
                    <label htmlFor="prodColor" className="form-label">
                      Available Variants
                    </label>
                    <button
                      type="button"
                      onClick={handleAddAvailabilityField}
                      required={true}
                      className="btn btn-secondary mx-2 my-2"
                    >
                      Add Variant
                    </button>
                    <hr></hr>
                  </div>
                  {AvailabilityFields ? (
                    AvailabilityFields.map(
                      (field, index) =>
                        field && (
                          <div key={field.id}>
                            <div className="mb-3">
                              <label
                                htmlFor={`prodColor${field.id}`}
                                className="form-label"
                              >
                                Variant {field.id + 1}
                              </label>
                              <button
                                type="button"
                                onClick={() =>
                                  handleRemoveAvailabilityField(index)
                                }
                                className="btn btn-secondary mx-2 my-2"
                              >
                                Remove
                              </button>
                              <input
                                type="text"
                                className="form-control"
                                required={true}
                                id={`prodColor${field.id}`}
                                {...register(`prdColor${field.id}`)}
                              />
                            </div>
                            <div className="mb-3">
                              <label
                                htmlFor={`prdSizes${field.id}`}
                                className="form-label"
                              >
                                Sizes for {field.color}
                              </label>

                              <div className="input-group flex-nowrap mb-3">
                                {field.sizes &&
                                  Object.entries(field.sizes)
                                    .filter(([size]) => size === "S") // Filter only 'S' size
                                    .map(([size, value]) => (
                                      <div
                                        key={size}
                                        className="input-group flex-nowrap mb-3"
                                      >
                                        <span
                                          className="input-group-text"
                                          id="addon-wrapping"
                                        >
                                          {size}
                                        </span>
                                        <input
                                          type="number"
                                          className="form-control"
                                          placeholder="0"
                                          aria-label={size}
                                          aria-describedby="addon-wrapping"
                                          {...register(`prdSizeS${field.id}`)}
                                        />
                                      </div>
                                    ))}
                              </div>
                            </div>
                            <hr />
                          </div>
                        )
                    )
                  ) : (
                    <p>No availability fields</p>
                  )}
                </>
              )}

              <div className="mb-3">
                <h5>Links</h5>
                <hr></hr>
                <label htmlFor="linkFacebook" className="form-label">
                  Facebook
                </label>
                <input
                  type="text"
                  className="form-control mb-3"
                  id="linkFacebook"
                  aria-describedby="emailHelp"
                  {...register("fbLink")}
                />

                <label htmlFor="linkTiktok" className="form-label">
                  Tiktok
                </label>
                <input
                  type="text"
                  className="form-control mb-3"
                  id="linkTiktok"
                  aria-describedby="emailHelp"
                  {...register("tiktokLink")}
                />

                <label htmlFor="linkInstagram" className="form-label">
                  Instagram
                </label>
                <input
                  type="text"
                  className="form-control mb-3"
                  id="linkInstagram"
                  aria-describedby="emailHelp"
                  {...register("instaLinks")}
                />

                <hr></hr>
              </div>

              {/* IMAGE BUTTON */}
              <div className="mb-3">
                <UploadButton onUpload={handleUploadSuccess} />
              </div>

              <div className="mb-3 text-center border border-dark p-1">
                {!imageUrl ? (
                  <img alt="" src={content.prdImage} width={150} height={150} />
                ) : (
                  <ImageUploadPreview
                    imageUrl={imageUrl}
                    width={150}
                    height={150}
                    alt=""
                  />
                )}
              </div>

              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  data-bs-dismiss="modal"
                  onClick={handleDismiss}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn btn-primary"
                  data-bs-dismiss="modal"
                  disabled={!isFormValid()}
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EditProductsForm;
