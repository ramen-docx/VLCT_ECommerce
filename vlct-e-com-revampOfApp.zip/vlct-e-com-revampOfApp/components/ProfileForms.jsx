"use client";
import styles from "@/styles/profile.module.css";
import UploadButton from "@/components/UploadButton";
import ConfirmSaveModal from "./ConfirmSaveModal";
import ConfirmDeleteModal from "./ConfirmDeleteModal";

// react imports
import React from "react";
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useRouter } from "next/navigation";
import { signOut, useSession } from "next-auth/react";
import axios from "axios";
import Link from "next/link";

function ProfileForms() {
  const { data: session } = useSession();
  const router = useRouter();
  //utils
  const [error, setError] = useState("");
  const [editingMode, setEditingMode] = useState(false);
  const [contents, setContents] = useState({});

  const [updatedUserData, setUpdatedUserData] = useState({});
  const [selectedGender, setSelectedGender] = useState("");
  const [selectedPronouns, setSelectedPronouns] = useState("");
  const [profileImg, setProfileImg] = useState(contents.uImg);
  const [email, setEmail] = useState(session?.user?.email);
  const [loggedEmail, setLoggedEmail] = useState(session.user.email);
  useEffect(() => {
    axios
      .get(`/api/register/${email}`)
      .then((res) => {
        setContents(res.data.user);
      })
      .catch((error) => {
        console.log("Error fetching user data:", error);
      });
  }, [email]);

  const {
    register,
    handleSubmit,
    watch,
    reset,
    setValue,
    formState: { errors },
  } = useForm({
    defaultValues: {
      uName: contents.uName,
      uEmail: contents.uEmail,
      uFName: contents.uFName,
      uLName: contents.uLName,
      uGender: contents.uGender,
      uPronouns: contents.uPronouns,
      uBirthdate: contents.uBirthdate,
      uImg: contents.uImg,
    },
  });
  useEffect(() => {
    setValue("uName", contents.uName);
    setValue("uEmail", contents.uEmail);
    setValue("uFName", contents.uFName);
    setValue("uLName", contents.uLName);
    setValue("uGender", contents.uGender);
    setValue("uPronouns", contents.uPronouns);
    setValue("uBirthdate", contents.uBirthdate);
    setValue("uImg", contents.uImg);
    setProfileImg(contents.uImg);
  }, [contents]);

  const handleUploadSuccess = (result) => {
    // if (
    //   result.type === "image/jpeg" ||
    //   result.type === "image/png" ||
    //   result.type === "image/jpg"
    // ) {
    setProfileImg(result.info.secure_url);
    // } else {
    //   alert("Only JPEG and PNG files are allowed!");
    //   console.log("Invalid file type: ", result);
    // }
  };
  const handleDismiss = () => {
    setValue("uName", contents.uName);
    setValue("uEmail", contents.uEmail);
    setValue("uFName", contents.uFName);
    setValue("uLName", contents.uLName);
    setValue("uGender", contents.uGender);
    setValue("uPronouns", contents.uPronouns);
    setValue("uBirthdate", contents.uBirthdate);
    setProfileImg(contents.uImg);
    setEditingMode(false);
  };
  const saveDataChecker = (data, e) => {
    e.preventDefault();
    setUpdatedUserData({ ...data, uImg: profileImg });
  };

  return (
    <>
      <div className={styles.bgImage}>
        <div className={styles.profilecontainer}>
          {/* ========================================= remaining form code ========================================= */}
          <div className={styles.formCorner}>
            <form onSubmit={handleSubmit(saveDataChecker)}>
              <div className={styles.imageUpload}>
                <img
                  src={
                    !profileImg ? "images/defaultProfilePic.png" : profileImg
                  }
                  alt=""
                  width="300"
                  height="300"
                  className={`${styles.profImg} mx-auto d-block`}
                />
                {editingMode && <UploadButton onUpload={handleUploadSuccess} />}
              </div>

              <h2>PROFILE</h2>
              {error && <div className="alert alert-danger">{error}</div>}
              <div className={styles.formRow}>
                <div className="col-md-6 mr-3">
                  <div className={styles.formGroup}>
                    <label htmlFor="firstName">Username:</label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Username"
                      id="username"
                      name="username"
                      disabled={!editingMode}
                      {...register("uName")}
                    />
                  </div>
                  <div className={styles.formGroup}>
                    <label htmlFor="email">Email:</label>
                    <input
                      type="email" // Use "email" type for email fields
                      className="form-control"
                      placeholder="Email"
                      id="email"
                      name="email"
                      disabled={true}
                      {...register("uEmail")}
                    />
                  </div>
                  <div className={styles.formGroup}>
                    <label htmlFor="firstName">First name:</label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder="First Name"
                      id="firstName"
                      name="firstName"
                      disabled={!editingMode}
                      {...register("uFName")}
                    />
                  </div>
                  <div className={styles.formGroup}>
                    <label htmlFor="lastName">Last name:</label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Last Name"
                      id="lastName"
                      name="lastName"
                      onChange=""
                      disabled={!editingMode}
                      {...register("uLName")}
                    />
                  </div>
                </div>

                <div className="col-md-6">
                  <div className={styles.formGroup}>
                    <label htmlFor="birthdate">Birthdate:</label>
                    <input
                      type="date"
                      className="form-control"
                      id="birthdate"
                      name="birthdate"
                      onChange=""
                      disabled={!editingMode}
                      {...register("uBirthdate")}
                    />
                  </div>

                  <div className={styles.formGroup}>
                    <label htmlFor="gender">Gender:</label>
                    <select
                      className={`${styles.selectBox} form-select form-select mt-sm-1 mb-sm-4 ms-sm-1 p-2 rounded-3 `}
                      aria-label="Gender Select"
                      defaultValue={contents.uGender}
                      disabled={!editingMode}
                      {...register("uGender")}
                    >
                      <option>Male</option>
                      <option>Female</option>
                      <option>Others</option>
                    </select>
                  </div>

                  <div className={styles.formGroup}>
                    <label htmlFor="pronouns">Pronouns:</label>
                    <select
                      className={`${styles.selectBox} form-select form-select mt-sm-1 ms-sm-1 p-2 rounded-3`}
                      aria-label="Gender Select"
                      defaultValue={contents.uPronouns}
                      disabled={!editingMode}
                      {...register("uPronouns")}
                    >
                      <option>He / Him</option>
                      <option>She / Her</option>
                      <option>They / Them</option>
                      <option>Others</option>
                    </select>
                  </div>
                </div>
              </div>
              <div className="row justify-content-center d-flex">
                <div className="text-center mt-4">
                  {!editingMode && (
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={() => {
                        setEditingMode(true);
                      }}
                    >
                      Edit Profile
                    </button>
                  )}
                  {"  "}
                  {editingMode && (
                    <>
                      <button
                        type="button"
                        className="btn btn-secondary"
                        onClick={handleDismiss}
                      >
                        Cancel
                      </button>
                      {"  "}
                      <button
                        className="btn btn-primary"
                        data-bs-toggle="modal"
                        data-bs-target="#confirmSaveModal"
                      >
                        Save Changes
                      </button>
                    </>
                  )}
                </div>
                <div className="text-center mt-4"></div>
              </div>
            </form>
            <ConfirmSaveModal
              loggedEmail={loggedEmail}
              updatedUserData={updatedUserData}
              setError={setError}
              setEditingMode={setEditingMode}
            />
            <ConfirmDeleteModal
              loggedEmail={loggedEmail}
              updatedUserData={updatedUserData}
              setError={setError}
            />

            <div className="row justify-content-center">
              <div className="col-md-2">
                <div className="text-center mt-3">
                  <Link href="/changepassword">
                    <button className="btn btn-warning w-100">
                      Change Password
                    </button>
                  </Link>
                </div>
              </div>
              <div className="col-md-2">
                <div className="text-center mt-3">
                  <button
                    className="btn btn-danger w-100"
                    data-bs-toggle="modal"
                    data-bs-target="#confirmDeleteModal"
                  >
                    Delete Account
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default ProfileForms;
