"use client";
import GoogleButton from "react-google-button";
import styles from "@/styles/login.module.css";

// react imports
import React from "react";
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useRouter } from "next/navigation";
import { signIn, useSession } from "next-auth/react";
import axios from "axios";
import Link from "next/link";

function LoginForm() {
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);
  const router = useRouter();
  const { data: session } = useSession();

  const {
    register,
    handleSubmit,
    watch,
    reset,
    formState: { errors },
  } = useForm();

  const handleLogin = async (data) => {
    const emailOrUsername = watch("emailOrUsername");
    const enteredPassword = watch("uPassword");
    setPending(true);

    const res = await signIn("credentials", {
      email: emailOrUsername,
      password: enteredPassword,
      redirect: false,
    });
    console.log("res: ", res);
    if (res.error) {
      setError("Username or password is incorrect.");
      return;
    } else {
      setError("");
      router.push("/");
    }

    setPending(false);
  };

  return (
    <div className={styles.bgImage}>
      <div className={`${styles.loginBox} container text-center my-5`}>
        <div className="login-container mx-md-5">
          <div className="login__group">
            <br />
            <h2 className="mb-4">LOGIN</h2>

            {error && <div className="alert alert-danger">{error}</div>}

            {/* ======================= begining form ======================= */}
            <form onSubmit={handleSubmit(handleLogin)}>
              <div className="form-floating mb-3 mx-3">
                <input
                  type="text"
                  id="emailOrUsername"
                  name="emailOrUsername"
                  required
                  placeholder="Email or Username"
                  className="form-control"
                  {...register("emailOrUsername")}
                />
                <label htmlFor="floatingInput"> Email or Username</label>
              </div>
              <div className="form-floating mb-0 mx-3">
                <input
                  type="password"
                  id="password"
                  name="password"
                  required
                  placeholder="Password"
                  className="form-control"
                  {...register("uPassword")}
                />
                <label htmlFor="floatingInput">Password</label>
              </div>
              <br /> <br />
              <button
                className={`${styles.loginbutton} btn btn-light login-button mb-3`}
              >
                Login
              </button>
            </form>
            {/* ======================= end of form ======================= */}

            <center>
              <GoogleButton
                onClick={() => {
                  signIn("google");
                }}
              />
            </center>
            <br></br>
            <div className="container mb-3">
              <p>
                Don't have an account?{" "}
                <Link href="/register" className="text-decoration-none">
                  Register here
                </Link>
              </p>
              <p>
                <Link href="/forgot" className="text-decoration-none">
                  Forgot Password
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LoginForm;
