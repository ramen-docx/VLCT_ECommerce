"use client";
//Custom made shiz
import AddProductsForm from "@/components/AddProductsForm";
import EditProductsForm from "@/components/EditProductsForm";
import ProductsDeleteModal from "@/components/ProductsDeleteModal";
import styles from "@/styles/manageproducts.module.css";
import ImageUploadPreview from "@/components/ImageUploadPreview";
import UploadButton from "@/components/UploadButton";

// react imports
import React from "react";
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useRouter } from "next/navigation";
import { signOut, useSession } from "next-auth/react";
import axios from "axios";
import Link from "next/link";

function ManageProducts() {
  const [products, setProducts] = useState([]);
  const [yeetedID, setYeetedID] = useState();
  const [yeetedProducts, setYeetedProducts] = useState([]);
  const [deleteProductID, setDeleteProductID] = useState();
  const [error, setError] = useState("");
  const router = useRouter();

  const {
    register,
    handleSubmit,
    watch,
    reset,
    formState: { errors },
  } = useForm();
  useEffect(() => {
    axios.get("/api/product").then((response) => {
      setProducts(response.data);
    });
  }, []);

  function useSetYeetedShiz(ID, content) {
    setYeetedID(ID);
    setYeetedProducts(content);
  }

  const handleOpenEditModal = () => {};
  const deleteProduct = (prdID) => {
    axios.delete(`/api/product/${prdID}`).then((response) => {
      setProducts((previousProducts) =>
        previousProducts.filter((products) => products._id !== prdID)
      );
    });
  };

  return (
    <>
      <div className="bg-light ">
        <div className="container-fluid bg-light border-top mt-1 p-2">
          <h1 className="text-center fw-bold">Manage Products</h1>
          <div className="row border-top border pt-2 px-2 bg-white mx-1">
            <div className="col-6 text-start">
              <h3>Product List</h3>
            </div>
            <div className="col-6 text-end">
              <button
                type="button"
                className={`${styles.addBtnSize} btn btn-primary mx-2 mb-2`}
                data-bs-toggle="modal"
                data-bs-target="#addModal"
              >
                Add Products
              </button>

              {/*   =============================  Add Modal  =============================  */}
              <AddProductsForm setProducts={setProducts} setError={setError} />
              {/*   =============================  Edit Modal  =============================  */}
              <EditProductsForm
                setProducts={setProducts}
                productID={yeetedID}
                content={yeetedProducts}
                setError={setError}
                setYeetedProducts={setYeetedProducts}
              ></EditProductsForm>
            </div>
          </div>
        </div>
        <div className="container-fluid bg-light border-top mt-1 p-2">
          {error && (
            <div className="alert alert-danger text-center">{error}</div>
          )}
        </div>

        <div className={`${styles.tableContent} container-fluid`}>
          {/*   =============================  Table  =============================  */}
          <table
            className={`${styles.tableSize} table table-bordered table-white text-center`}
          >
            {/*  =============================  THeader  =============================  */}
            <thead className="sticky-top">
              <tr>
                {/* <th scope="col">Hide Product</th> */}
                <th scope="col">Product Name</th>
                <th scope="col">Image</th>
                <th scope="col">Price</th>
                <th scope="col" className={styles.oneline}>
                  Description
                </th>
                <th scope="col">Variant</th>

                <th scope="col">Actions</th>
              </tr>
            </thead>
            {/*  =============================  TBody  =============================  */}
            <tbody>
              {/* Loop for body contents */}
              {products.map((content) => {
                return (
                  <tr key={content._id}>
                    {/* <th scope="row">
                      <input
                        className="form-check-input border border-primary justify-content-center"
                        type="checkbox"
                        value=""
                        id="prdHide"
                      />
                    </th> */}
                    <td className={styles.oneline}>{content.prdName}</td>
                    <td className="text-center">
                      <img
                        src={content.prdImage}
                        alt=""
                        className={`${styles.imageSize} d-inline-block align-text-top p-1`}
                      />
                    </td>
                    <td className={styles.oneline}>{content.prdPrice}</td>
                    <td className={styles.oneline}>{content.prdDescription}</td>

                    <td className={styles.onelineColor}>
                      {content.prdAvailability &&
                      content.prdAvailability.length > 0 ? (
                        <div className="table-responsive">
                          <table className="table table-bordered border-dark table-sm">
                            <tbody>
                              {content.prdAvailability.map(
                                (availability, index) => (
                                  <React.Fragment key={index}>
                                    {/* Color */}
                                    <tr>
                                      <td
                                        className={`${styles.oneline} fw-bold`}
                                      >
                                        {availability.color}
                                      </td>
                                    </tr>
                                    {/* Stocks/Sizes */}
                                    <tr>
                                      <td>
                                        <strong>
                                          {content.prdCategory !== "Apparel"
                                            ? "Stocks:"
                                            : "Sizes"}
                                        </strong>
                                        {content.prdCategory !== "Apparel" ? (
                                          <span>{availability.sizes.S}</span>
                                        ) : (
                                          <table className="table table-bordered border-dark table-sm">
                                            <tbody>
                                              {Object.entries(
                                                availability.sizes
                                              ).map(([size, quantity]) => (
                                                <tr key={size}>
                                                  <td className="fw-bold">
                                                    {size}
                                                  </td>
                                                  <td>{quantity}</td>
                                                </tr>
                                              ))}
                                            </tbody>
                                          </table>
                                        )}
                                      </td>
                                    </tr>
                                    <br />
                                  </React.Fragment>
                                )
                              )}
                            </tbody>
                          </table>
                        </div>
                      ) : (
                        <div>No Variants Available</div>
                      )}
                    </td>

                    <td>
                      <button
                        type="button"
                        className={`${styles.btnSize} btn btn-primary mx-0 mx-md-2 p-0 p-md-1`}
                        data-bs-toggle="modal"
                        data-bs-target="#editModal"
                        onClick={() => {
                          useSetYeetedShiz(content._id, content);
                        }}
                      >
                        Edit
                      </button>

                      <button
                        type="button"
                        className={`${styles.btnSize} btn btn-danger mx-0 mx-md-2 p-0 p-md-1`}
                        data-bs-toggle="modal"
                        data-bs-target="#productsDeleteModal"
                        onClick={() => {
                          setDeleteProductID(content._id);
                        }}
                      >
                        Delete
                      </button>
                      <ProductsDeleteModal
                        onDelete={() => deleteProduct(deleteProductID)}
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

export default ManageProducts;
