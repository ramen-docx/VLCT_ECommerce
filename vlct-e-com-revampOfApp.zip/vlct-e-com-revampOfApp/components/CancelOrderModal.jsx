import React from "react";

function CancelOrderModal({ onDelete }) {
  return (
    <div
      className="modal fade"
      id="cancelOrderModal"
      tabindex="-1"
      aria-labelledby="cancelOrderModalLabel"
      aria-hidden="true"
    >
      <div className="modal-dialog modal-dialog-centered text-start">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title" id="cancelOrderModalLabel">
              Cancel Order?
            </h5>
            <button
              type="button"
              className="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
            ></button>
          </div>
          <div className="modal-body">
            Are you sure you want to cancel this order?
          </div>
          <div className="modal-footer">
            <button
              type="button"
              className="btn btn-secondary"
              data-bs-dismiss="modal"
            >
              Close
            </button>
            <button
              type="button"
              className="btn btn-primary"
              onClick={onDelete}
              data-bs-dismiss="modal"
            >
              Confirm
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CancelOrderModal;
