import { useEffect, useState } from "react";
import dynamic from "next/dynamic";

const DynamicCldUploadButton = dynamic(
  () => import("next-cloudinary").then((mod) => mod.CldUploadButton),
  { ssr: false } // This will load the component only on client side
);

const presetName = process.env.NEXT_PUBLIC_CLOUDINARY_PRESET_NAME;

function UploadButton({ onUpload }) {
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const handleUpload = (files) => {
    if ((files.length = 1)) {
      alert("You can only upload one file at a time.");
      return;
    }
    onUpload(files[0]);
  };

  return isClient ? (
    <DynamicCldUploadButton uploadPreset={presetName} onUpload={onUpload} />
  ) : null;
}

export default UploadButton;
